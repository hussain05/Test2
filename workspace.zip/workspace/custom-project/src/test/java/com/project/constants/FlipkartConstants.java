package com.project.constants;

public enum FlipkartConstants {
	
	FlipkartUrl("https://www.flipkart.com/"),
	FlipkartPropertiesFile("Flipkart"),
	BrandLogo("BrandLogo"),
	SearchBar("SearchBar"),
	SearchButton("SearchButton");

	
	
	private final String value;

	private FlipkartConstants(String value) {
		this.value = value;
	}

	public String value() {
		return value;
	}
}
