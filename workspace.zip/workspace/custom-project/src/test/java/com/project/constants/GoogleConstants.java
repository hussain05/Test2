package com.project.constants;

public enum GoogleConstants {
	
	GoogleUrl("https://www.google.com/"),
	GooglePropertiesFile("Google"),
	BrandLogo("BrandLogo");

	
	
	private final String value;

	private GoogleConstants(String value) {
		this.value = value;
	}

	public String value() {
		return value;
	}
}
