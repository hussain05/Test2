package com.project.tests;

import com.project.base.Base;
import com.project.common.WebInteract;
import com.project.constants.FlipkartConstants;
import com.project.constants.LocatorTypes;

import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class FlipkartTest extends Base {
	WebInteract webInteract;

	@BeforeClass
	public void setUp() {
		openBrowser();
		setPropertyFileName(FlipkartConstants.FlipkartPropertiesFile.value());
		openUrl(FlipkartConstants.FlipkartUrl.value());
		webInteract = new WebInteract(driver, propertyFileName);
	}

	@Test
	public void verifyBrandLogo() {
		Assert.assertTrue(webInteract.getElement(LocatorTypes.XPATH.value(), FlipkartConstants.BrandLogo.value()).isDisplayed());
		if(webInteract.isElementPresentCheck(LocatorTypes.XPATH.value(), "edfd"))
			System.out.println("Pass");
		else
			System.out.println("Fail");
		webInteract.getElement(LocatorTypes.XPATH.value(), FlipkartConstants.SearchBar.value()).sendKeys("mobile");
		webInteract.getElement(LocatorTypes.XPATH.value(), FlipkartConstants.SearchButton.value()).click();
	}

	@AfterClass
	public void closeBrowser() {
		driver.close();
	}
}
