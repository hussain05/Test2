package com.project.tests;

import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.project.base.Base;
import com.project.common.WebInteract;
import com.project.constants.GoogleConstants;
import com.project.constants.LocatorTypes;

public class GoogleTest extends Base {
	WebInteract webInteract;

	@BeforeClass
	public void setUp() {
		openBrowser();
		setPropertyFileName(GoogleConstants.GooglePropertiesFile.value());
		openUrl(GoogleConstants.GoogleUrl.value());
		webInteract = new WebInteract(driver, propertyFileName);
	}

	@Test
	public void verifyBrandLogo() {
		Assert.assertTrue(webInteract.getElement(LocatorTypes.XPATH.value(), GoogleConstants.BrandLogo.value()).isDisplayed());
	}

	@AfterClass
	public void closeBrowser() {
		driver.close();
	}
}
