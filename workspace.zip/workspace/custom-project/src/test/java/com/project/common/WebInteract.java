package com.project.common;

import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebInteract {
	protected WebDriver driver;
	protected Properties prop;
	protected String propertyFileName;

	public WebInteract(WebDriver driver, String propertyFileName) {
		this.driver = driver;
		this.propertyFileName = propertyFileName;
	}

	public boolean isElementPresentCheck(String locatorType, String locator) {
		try {
			return driver.findElement(getBy(locatorType, getLocator(locator))).isDisplayed();
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public boolean isElementsPresentCheck(String locatorType, String locator) {
		try {
			getElements(locatorType, locator);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public WebElement getElement(String locatorType, String locator) {
		return driver.findElement(getBy(locatorType, getLocator(locator)));
	}

	public List<WebElement> getElements(String locatorType, String locator) {
		return driver.findElements(getBy(locatorType, getLocator(locator)));
	}

	public void scrollDownToElement(String locatorType, String locator) {
		JavascriptExecutor jse;
		while (!isElementPresentCheck(locatorType, locator)) {
			jse = (JavascriptExecutor) driver;
			jse.executeScript("window.scrollBy(0,100)", "");
		}
	}

	public void scrollUpToElement(String locatorType, String locator) {
		JavascriptExecutor jse;
		while (!isElementPresentCheck(locatorType, locator)) {
			jse = (JavascriptExecutor) driver;
			jse.executeScript("window.scrollBy(0,-100)", "");
		}
	}

	public void scrollDownToElement(WebElement webElement) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", webElement);
	}

	public void hoverOnElement(String locatorType, String locator) {
		WebElement webElement = getElement(locatorType, locator);
		Actions builder = new Actions(driver);
		Action mouseOver = builder.moveToElement(webElement).build();
		mouseOver.perform();
	}

	public void hoverOnElement(WebElement we) {
		Actions builder = new Actions(driver);
		builder.moveToElement(we, 800, 280).click().build().perform();
	}

	public String getLocator(String locatorName) {
		prop = ReadProperties.readPropertyFile(propertyFileName);
		return prop.getProperty(locatorName);
	}

	public By getBy(String locatorType, String locator) {
		By by;
		switch (locatorType) {
		case "xpath":
			by = By.xpath(locator);
			break;
		case "id":
			by = By.id(locator);
			break;
		case "css":
			by = By.cssSelector(locator);
			break;
		case "class":
			by = By.className(locator);
			break;
		case "tag":
			by = By.tagName(locator);
			break;
		default:
			by = null;
			break;
		}
		return by;
	}

	public void explicitWaitForElement(String locatorType, String locator, int wait) {
		int second;
		for (second = 0;; second++) {
			if (second >= wait) {
				break;
			}
			if (isElementPresentCheck(locatorType, locator)) {
				break;
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public void explicitWaitForElement(String locator, int wait) {
		(new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath(locator)));
	}

	public void waitforElementTextChange(String locator) {
		String retrieved_text = getElement("xpath", locator).getText();
		int second;
		for (second = 0;; second++) {
			if (second >= 25) {
				break;
			}
			if (!getElement("xpath", locator).getText().equals(retrieved_text)) {
				break;
			}
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
