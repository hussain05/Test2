package com.project.listeners;

import org.testng.ISuite;
import org.testng.ISuiteListener;

import com.project.base.Base;

public class SuiteListeners extends Base implements ISuiteListener {
	public void onStart(ISuite suite) {
		System.out.println("================= Started ================");
		setBrowserType(suite.getParameter("Browser"));
		System.out.println("Execution started on: "+getBrowserType());
	}

	public void onFinish(ISuite suite) {
		System.out.println("================= Finished ================");
	}
}