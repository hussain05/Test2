package com.project.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Base {
	protected WebDriver driver;
	protected static String browserType;
	protected String propertyFileName;

	public void setDriver() {
		if (browserType.equals("Firefox"))
			driver = new FirefoxDriver();
		else {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-extensions");
			driver = new ChromeDriver(options);
		}
		maximizeWindow();
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void maximizeWindow() {
		driver.manage().window().maximize();
	}

	public static void setBrowserType(String browser) {
		browserType = browser;
	}
	public static String getBrowserType() {
		return browserType;
	}

	public void openBrowser() {
		setDriver();
	}

	public void openUrl(String url) {
		driver.get(url);
	}

	public String getCurrentUrl() {
		return driver.getCurrentUrl();
	}

	public void navigateBack() {
		driver.navigate().back();
	}

	public void setPropertyFileName(String PropertyFileName) {
		propertyFileName = PropertyFileName;
	}

	public String getPropertyFileName() {
		return propertyFileName;
	}
}
