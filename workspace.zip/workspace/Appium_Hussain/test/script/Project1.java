package script;



import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import com.thoughtworks.selenium.Selenium;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;



public class Project1 {
//	private Selenium selenium;
	AppiumDriver driver;
	String baseUrl;
	DesiredCapabilities capabilities = new DesiredCapabilities();

	@BeforeTest 
	public void beforeTest() throws Exception {
		
		
		/*capability = new DesiredCapabilities();
		capability.setBrowserName("FireFox");*/
		capabilities.setCapability("browserName", "Chrome");
		capabilities.setCapability("deviceName", "Moto");
		capabilities.setCapability("automationName", "Appium");
		capabilities.setCapability("udid", "ZX1D62R9CS");
		capabilities.setCapability("platformVersion", "6.0");
		capabilities.setCapability("platformName", "Android");
		
		//capability.setBrowserName("firefox");
		//capability.setPlatform(Platform.VISTA);
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);
	//	driver.manage().window().maximize();
		baseUrl = "https://www.annauniv.edu/";
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	}

	@Test
	public void testWiki_wb() throws Exception {
		driver.get("https://www.wikipedia.org/");
		//selenium.open("");
		driver.findElement(By.cssSelector("strong"));
		driver.findElement(By.id("searchInput")).sendKeys("selenium");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"search-form\"]/fieldset/button/i")).click();
		//driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		Thread.sleep(5000);
	System.out.println(driver.getTitle());
		Assert.assertEquals("Selenium - Wikipedia, the free encyclopedia",driver.getTitle());
		Assert.assertEquals("Selenium", driver.findElement(By.id("section_0")).getText());
				//selenium.getText("id=firstHeading"));
		
		
	}

	@AfterTest
	public void afterTest() throws Exception {
		driver.quit();
	}
}

