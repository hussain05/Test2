package script;



import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.android.AndroidDriver;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import com.thoughtworks.selenium.Selenium;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.internal.MultiAction;
import org.openqa.selenium.interactions.internal.TouchAction;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;



public class Project2 {
	private Selenium selenium;
	AppiumDriver driver;
	String baseUrl;
	DesiredCapabilities capabilities = new DesiredCapabilities();

	@BeforeTest 
	public void beforeTest() throws Exception {
		
		
		/*capability = new DesiredCapabilities();
		capability.setBrowserName("FireFox");*/
		capabilities.setCapability("browserName", "Chrome");
		capabilities.setCapability("deviceName", "Moto");
		capabilities.setCapability("automationName", "Appium");
		capabilities.setCapability("udid", "50681106"); //ZX1D62R9CS
		
		capabilities.setCapability("platformVersion", "6.0");
		capabilities.setCapability("platformName", "Android");
		
		//capability.setBrowserName("firefox");
		//capability.setPlatform(Platform.VISTA);
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);
	//	driver.manage().window().maximize();
		baseUrl = "http://www.crossword.in/";
		//driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	}

	@Test
	public void testWiki_wb() throws Exception {
		driver.get(baseUrl);
		//selenium.open("");
		//driver.findElement(By.xpath("//*[@id=\"hd\"]/div/div/div/div[2]/nav/div[1]/button[3]/span"));
		driver.findElement(By.cssSelector("button.navbar-toggle.navbar-search-toggle")).click();
		Thread.sleep(10000);
	    driver.findElement(By.xpath("//*[@id=\"search-input\"]")).sendKeys("cricket");
	   
	    driver.findElement(By.xpath("//*[@id=\"search\"]/span[3]/input")).click();
	    Thread.sleep(10000);
	    driver.findElement(By.xpath("//*[@id=\"search-results\"]/div[2]/div[3]/span[2]/a[3]")).click();
	    Thread.sleep(5000);
	    String value, value2;
	    int value_int, value_int2, results_count;
	    results_count = Integer.parseInt(driver.findElement(By.xpath("//*[@id=\"search-results\"]/div[2]/div[1]/span[1]")).getText().replaceAll("[^0-9]", ""));
	    
	    while(!isElementPresent(By.xpath(".//*[@id='search-result-items']/li["+results_count+"]/div/div[2]/span[1]/a")))
	    //while(driver.findElements(By.xpath("//*[@id=\"search-result-items\"]/li["+results_count+"]/div/div[2]/span[1]/a")).isEmpty())
	    	//*[@id="search-result-items"]/li[82]/div/div[2]/span[1]/a
	    	
	    {
	    	/*JavascriptExecutor jse = (JavascriptExecutor)driver;
	    	jse.executeScript("window.scrollBy(0,2500)", "");*/ //Scroll down
	    	
	    	driver.context("NATIVE_APP"); 
	    	Dimension size = driver.manage().window().getSize(); 
	    	int starty = (int) (size.height * 0.65); 
	    	int endy = (int) (size.height * 0.25); 
	    	int startx = size.width / 2; 
	    	driver.swipe(startx, starty, startx, endy, 500);
	    	//MultiTouchAction mta = new MultiTouchAction(driver);
	    	
	    	
	    	//mta.add(ta).perform();
	    	
	    	//Thread.sleep(2000);
	    }
	    
	    for(int i=1;i<results_count;i++)
	    {
	    	if(!driver.findElements(By.xpath(".//*[@id='search-result-items']/li["+i+"]/div/div[2]/span[3]/span[3]/span")).isEmpty())
	    	
	    	{
	    		value = driver.findElement(By.xpath(".//*[@id='search-result-items']/li["+i+"]/div/div[2]/span[3]/span[3]/span")).getText().replaceAll("[^0-9]", "");
	        	
	    	}
	    	else
	    	{
	    		value = driver.findElement(By.xpath(".//*[@id='search-result-items']/li["+i+"]/div/div[2]/span[3]/span/span")).getText().replaceAll("[^0-9]", "");  
	    	//	System.out.println(value);
	    	}
	    	
	    	if(!driver.findElements(By.xpath(".//*[@id='search-result-items']/li["+(i+1)+"]/div/div[2]/span[3]/span[3]/span")).isEmpty())
	    	{
	    		value2 = driver.findElement(By.xpath(".//*[@id='search-result-items']/li["+(i+1)+"]/div/div[2]/span[3]/span[3]/span")).getText().replaceAll("[^0-9]", "");  
	    	}
	        	
	    	
	    	else
	    	{
	    		value2 = driver.findElement(By.xpath(".//*[@id='search-result-items']/li["+(i+1)+"]/div/div[2]/span[3]/span/span")).getText().replaceAll("[^0-9]", "");  
	    	}
	    	
	    	
	    	value_int = Integer.parseInt(value);
	    	value_int2 = Integer.parseInt(value2);
	    	
	    	
	    	//value_int = Integer.parseInt(value);
	    	//System.out.println(value);
	    	if(value_int<value_int2)
	    	{
	    		System.out.println("FAILED as value of product "+i+ "(" +value_int+ ") is less than value of product "+(i+1)+" ("+value_int2+")");
	    		
	    	}
	    	/*Actions action;
	    	action = new Actions(driver);
	    	action.sendKeys(Keys.DOWN);*/
	    	
	    }
	    
		
	}

	@AfterTest
	public void afterTest() throws Exception {
		driver.quit();
	}
	 private boolean isElementPresent(By by) {
		    try {
		      driver.findElement(by);
		      return true;
		    } catch (NoSuchElementException e) {
		      return false;
		    }
		  }
}

