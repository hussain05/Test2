package script;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import com.thoughtworks.selenium.Selenium;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

public class Project5 {

	AppiumDriver driver;

	DesiredCapabilities capabilities = new DesiredCapabilities();

	@BeforeTest
	public void beforeTest() throws Exception {

		/*
		 * capability = new DesiredCapabilities();
		 * capability.setBrowserName("FireFox");
		 */
		// capabilities.setCapability("browserName", "Chrome");
		capabilities.setCapability("deviceName", "Moto");
		capabilities.setCapability("automationName", "Appium");
		capabilities.setCapability("udid", "ZX1D62R9CS");
		capabilities.setCapability("platformVersion", "6.0");
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("appPackage", "com.whatsapp");
		capabilities.setCapability("appActivity",
				"com.whatsapp.Main");
		// capability.setBrowserName("firefox");
		// capability.setPlatform(Platform.VISTA);
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),
				capabilities);

		// driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	}

	@Test
	public void whatsapp() throws Exception {

		try{
		while(driver.findElement(
				By.id("com.whatsapp:id/conversations_row_message_count")).isDisplayed())
		{
			driver.findElement(
					By.id("com.whatsapp:id/conversations_row_message_count")).click();
			driver.findElement(
					By.id("com.whatsapp:id/entry")).sendKeys("hi");
			driver.findElement(
					By.id("com.whatsapp:id/send")).click();
			driver.findElement(
					By.id("com.whatsapp:id/up")).click();
			
		}
		}
		catch(NoSuchElementException e)
		{
			System.out.println("No new messages");
		}
		
		

	}

	@AfterTest
	public void afterTest() throws Exception {
		driver.quit();
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
}
