package script;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

public class Test1_Chrome1 {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	Test1_Pagefactory1 Test_PF;

	@BeforeTest
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"..\\test\\resources\\chromedriver.exe");//..\\ added so that build can work on ANT
		driver = new ChromeDriver();

		baseUrl = "http://www.barnesandnoble.com";
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Test_PF = PageFactory.initElements(driver,
				Test1_Pagefactory1.class);
	}

	@Test
	public void Test1_Chrome() throws Exception {
		driver.get(baseUrl);
		/*driver.findElement(By.id("searchBarBN")).clear();
	    driver.findElement(By.id("searchBarBN")).sendKeys("Hamilton: The Revolution");
	    driver.findElement(By.id("searchSubmit")).click();*/
	    Test_PF._searchField.clear();
	    Test_PF._searchField.sendKeys("Hamilton: The Revolution");
		Test_PF._searchButton.click();
		Thread.sleep(3000);
	    driver.findElement(By.xpath(".//*[@id='gridView']/li/ul[1]/li[1]/div[1]/a[1]/img")).click();
	    Assert.assertTrue(driver.findElement(By.xpath(".//*[@id='prodSummary']/span/a[1]")).getText().equals("Lin-Manuel Miranda"));
	    Assert.assertTrue(driver.findElement(By.xpath(".//*[@id='additionalProductInfo']/dl/dd[1]")).getText().equals("9781455539741"));  //This fails as actual value is 9781455567539
		
	}

	@AfterTest
	public void tearDown() throws Exception {
		driver.quit();
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
