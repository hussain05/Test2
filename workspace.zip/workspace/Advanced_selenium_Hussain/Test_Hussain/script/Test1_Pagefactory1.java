package script;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Test1_Pagefactory1 {

	@FindBy(how = How.ID, using = "searchSubmit")
	WebElement _searchButton;
	
	@FindBy(id = "searchBarBN")
	WebElement _searchField;
	
	
	
}
