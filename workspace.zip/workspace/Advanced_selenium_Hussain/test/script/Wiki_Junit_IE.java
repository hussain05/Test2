
package script;

import static org.junit.Assert.*;

import com.thoughtworks.selenium.Selenium;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.WebDriver;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class Wiki_Junit_IE {
	private Selenium selenium;
WebDriver driver;
	@Before
	public void setUp() throws Exception {
		
		
		System.setProperty("webdriver.ie.driver","test\\resources\\IEDriverServer.exe"); //for IE
		//WebDriver driver = new ChromeDriver(); //for IE
		 driver = new InternetExplorerDriver();
		String baseUrl = "https://www.wikipedia.org/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);  //For RC commands below; better remove if using PURE webdriver code
	}

	@Test
	public void testWiki_wb() throws Exception {
		selenium.open("");
		selenium.click("css=strong");
		selenium.waitForPageToLoad("60000");
		selenium.type("id=searchInput", "selenium");
		selenium.click("id=searchButton");
		selenium.waitForPageToLoad("60000");
		assertEquals("Selenium - Wikipedia, the free encyclopedia", selenium.getTitle());
		assertEquals("Selenium", selenium.getText("id=firstHeading"));
		//assertEquals(By.id("firstHeading").toString(),"Selenium");
	}

	@After
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
