package script;

import java.net.URL;
import com.thoughtworks.selenium.Selenium;

import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class GRID2 {
	private Selenium selenium;
	WebDriver driver;
	String baseUrl;

	@BeforeTest
	public void beforeTest() throws Exception {

		DesiredCapabilities capability;
		/*
		 * capability = new DesiredCapabilities();
		 * capability.setBrowserName("FireFox");
		 */
		capability = DesiredCapabilities.firefox();
		// capability.setBrowserName("firefox");
		// capability.setPlatform(Platform.VISTA);
		driver = new RemoteWebDriver(new URL("http://172.21.35.104:4444/web/hub"), capability);
		driver.manage().window().maximize();
		baseUrl = "https://www.annauniv.edu/";
		// driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testWiki_wb() throws Exception {
		driver.get("https://www.annauniv.edu/");
		driver.findElement(By
				.xpath("html/body/table/tbody/tr[1]/td[1]/table/tbody/tr/td[1]/table/tbody/tr/td/table/tbody/tr/td[5]/div"))
				.click();
		Actions action = new Actions(driver);

		Actions builder = new Actions(driver);
		WebElement we2 = driver.findElement(By.xpath(".//*[@id='link3']/strong"));

		Action mouseOver = builder.moveToElement(we2).build();
		mouseOver.perform();

		WebElement we1 = driver.findElement(By.xpath(".//*[@id='menuItemHilite32']"));
		action.moveToElement(we1).click().build().perform();
		// driver.findElement(By.id(".//*[@id='menuItemHilite32']")).click();
	}

	@AfterTest
	public void afterTest() throws Exception {
		driver.quit();
	}
}
