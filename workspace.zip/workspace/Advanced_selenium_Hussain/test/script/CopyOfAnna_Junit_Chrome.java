package script;

import java.util.concurrent.TimeUnit;








import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;


import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

public class CopyOfAnna_Junit_Chrome {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	@BeforeTest
	public void setUp() throws Exception {
		//System.setProperty("webdriver.chrome.driver",
				//"test\\resources\\chromedriver.exe");

		driver = new ChromeDriver();

		baseUrl = "https://www.annauniv.edu/";
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testAnnaDeanW() throws Exception {
		driver.get("https://www.annauniv.edu/");
		
		/*
		if(driver.findElement(
				By.xpath("html/body/table/tbody/tr[1]/td[1]/table/tbody/tr/td[1]/table/tbody/tr/td/table/tbody/tr/td22[5]/div")).isDisplayed())
		{
			System.out.println("Pass");
			
		}
		else
		{
			System.out.println("Fail");
		}*/
		
		Assert.assertTrue(isElementPresentCheck("xpath", "dfjdhfdhf"));
				
		
	}

	@AfterTest
	public void tearDown() throws Exception {
		driver.quit();
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
	
	public boolean isElementPresentCheck(String locatorType, String locator) {
		try {
			getElement(locatorType, locator);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
	
	public WebElement getElement(String locatorType, String locator) {
		
			return driver.findElement(getBy(locatorType, locator));
		
	}
	
	public By getBy(String locatorType, String locator) {
		By by;
		switch (locatorType) {

		case "xpath":
			by = By.xpath(locator);
			break;

		case "id":
			by = By.id(locator);
			break;

		case "css":
			by = By.cssSelector(locator);
			break;

		case "class":
			by = By.className(locator);
			break;

		case "tag":
			by = By.tagName(locator);
			break;

		default:
			by = null;
			break;

		}
		return by;

	}
}
