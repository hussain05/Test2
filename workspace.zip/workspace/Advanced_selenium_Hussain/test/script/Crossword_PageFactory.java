package script;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Crossword_PageFactory {

	@FindBy(how = How.ID, using = "search-input")
	WebElement _searchField;
	
	@FindBy(css = "input.search-go")
	WebElement _searchButton;
	
	
	
}
