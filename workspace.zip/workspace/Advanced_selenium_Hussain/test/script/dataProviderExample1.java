//Data Driven Test Framework using Selenium and TestNG
//This Test performs search for the movie and looks for the attributes on the result page
//Data is read from the Excel SS - movie_data.xls
package script;

import com.thoughtworks.selenium.*;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;


import org.openqa.selenium.By;
//import org.junit.AfterClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;

import java.io.File;

import jxl.*; 

public class dataProviderExample1 extends SeleneseTestCase{
    WebDriver driver;
    String baseUrl;
    @Override
	@BeforeTest
    public void setUp() throws Exception {
    	WebDriver driver = new FirefoxDriver();
		baseUrl = "http://www.barnesandnoble.com/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
    }
    
    
    @DataProvider(name = "DP1")
    public Object[][] createData1() {
        Object[][] retObjArr=getTableArray("test\\resources\\movie_data.xls",
                "DataPool", "temp");
        return(retObjArr);
    }
    
	@Test (dataProvider = "DP1") 
	public void testDataProviderExample(String bookTitle, 
            String authorName, String bookSummary, String isbnNumber13) throws Exception {
		driver.get("http://www.barnesandnoble.com/");
	    driver.findElement(By.id("searchBarBN")).clear();
	    driver.findElement(By.id("searchBarBN")).sendKeys(bookTitle);
	    driver.findElement(By.id("searchSubmit")).click();
	}
    
    @Override
	@AfterClass
    public void tearDown(){
        selenium.close();
        selenium.stop();
    } 
    
    public String[][] getTableArray(String xlFilePath, String sheetName, String tableName){
        String[][] tabArray=null;
        try{
            Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));
            Sheet sheet = workbook.getSheet(sheetName);
            
            int startRow,startCol, endRow, endCol,ci,cj;
            
            Cell tableStart=sheet.findCell(tableName);
            startRow=tableStart.getRow();
            startCol=tableStart.getColumn();

            Cell tableEnd= sheet.findCell(tableName, startCol+1,startRow+1, 100, 64000,  false);                

            endRow=tableEnd.getRow();
            endCol=tableEnd.getColumn();
            
            System.out.println("startRow="+startRow+", endRow="+endRow+", " +
                    "startCol="+startCol+", endCol="+endCol);
            tabArray=new String[endRow-startRow-1][endCol-startCol-1];
            ci=0;

            for (int i=startRow+1;i<endRow;i++,ci++){
                cj=0;
                for (int j=startCol+1;j<endCol;j++,cj++){
                    tabArray[ci][cj]=sheet.getCell(j,i).getContents();
                }
            }
        }
        catch (Exception e)    {
            System.out.println("error in getTableArray()");
            
        }

        return(tabArray);
    }
   
}//end of class