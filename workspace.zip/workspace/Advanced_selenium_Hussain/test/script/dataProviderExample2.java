//Data Driven Test Framework using Selenium and TestNG
//This Test performs search for the movie and looks for the attributes on the result page
//Data is read from the Excel SS - movie_data.xls
package script;

import com.thoughtworks.selenium.*;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

//import org.junit.AfterClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;

import java.io.File;
import jxl.*; 

public class dataProviderExample2 extends SeleneseTestCase{
    
    @Override
	@BeforeTest
    public void setUp() throws Exception {
    	WebDriver driver = new FirefoxDriver();
		String baseUrl = "https://www.imdb.com";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
    }
    
    
    @DataProvider(name = "DP1")
    public Object[][] createData1() {
        Object[][] retObjArr=getTableArray("test\\resources\\movie_data.xls",
                "DataPool", "imdbTestData1");
        return(retObjArr);
    }
    
	@Test (dataProvider = "DP1") 
	public void testDataProviderExample(String movieTitle, 
            String directorName, String moviePlot, String actorName) throws Exception {
		selenium.open("http://www.imdb.com/");
		selenium.type("id=navbar-query", movieTitle);
		selenium.click("id=navbar-submit-button");
		for (int second = 0;; second++) {
			if (second >= 60) fail("timeout");
			try { if (selenium.isElementPresent("link="+movieTitle)) break; } catch (Exception e) {}
			Thread.sleep(1000);
		}

		selenium.click("link="+movieTitle);
		for (int second = 0;; second++) {
			if (second >= 60) fail("timeout");
			try { if (selenium.isElementPresent("xpath=/html/body[@id='styleguide-v2']/div[@id='wrapper']/div[@id='root']/div[@id='pagecontent']/div[@id='content-2-wide']/div[@id='maindetails_center_top']/div/div/table[@id='title-overview-widget-layout']/tbody/tr[1]/td[@id='overview-top']/div[6]/a[3]")) break; } catch (Exception e) {}
			Thread.sleep(1000);
		}

        verifyTrue(selenium.isTextPresent(directorName));
        //verify movie plot is present in the movie details page
        verifyTrue(selenium.isTextPresent(moviePlot));
        //verify movie actor name is present in the movie details page
        verifyTrue(selenium.isTextPresent(actorName));
	}
    
    @Override
	@AfterClass
    public void tearDown(){
        selenium.close();
        selenium.stop();
    } 
    
    public String[][] getTableArray(String xlFilePath, String sheetName, String tableName){
        String[][] tabArray=null;
        try{
            Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));
            Sheet sheet = workbook.getSheet(sheetName);
            
            int startRow,startCol, endRow, endCol,ci,cj;
            
            Cell tableStart=sheet.findCell(tableName);
            startRow=tableStart.getRow();
            startCol=tableStart.getColumn();

            Cell tableEnd= sheet.findCell(tableName, startCol+1,startRow+1, 100, 64000,  false);                

            endRow=tableEnd.getRow();
            endCol=tableEnd.getColumn();
            
            System.out.println("startRow="+startRow+", endRow="+endRow+", " +
                    "startCol="+startCol+", endCol="+endCol);
            tabArray=new String[endRow-startRow-1][endCol-startCol-1];
            ci=0;

            for (int i=startRow+1;i<endRow;i++,ci++){
                cj=0;
                for (int j=startCol+1;j<endCol;j++,cj++){
                    tabArray[ci][cj]=sheet.getCell(j,i).getContents();
                }
            }
        }
        catch (Exception e)    {
            System.out.println("error in getTableArray()");
            
        }

        return(tabArray);
    }
   
}//end of class