package script;



import java.net.URL;
import java.util.concurrent.TimeUnit;

import com.thoughtworks.selenium.Selenium;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;



public class GRID1 {
	private Selenium selenium;
	WebDriver driver;
	String baseUrl;
	

	@BeforeTest 
	public void beforeTest() throws Exception {
		
		DesiredCapabilities capability;
		/*capability = new DesiredCapabilities();
		capability.setBrowserName("FireFox");*/
		capability = DesiredCapabilities.chrome();
		//capability.setBrowserName("firefox");
		//capability.setPlatform(Platform.VISTA);
		driver = new RemoteWebDriver(new URL("http://172.21.46.61:6655/wd/hub"),DesiredCapabilities.firefox());
		driver.manage().window().maximize();
		baseUrl = "https://www.annauniv.edu/";
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testWiki_wb() throws Exception {
		driver.get("https://www.annauniv.edu/");
		driver.findElement(
				By.xpath("html/body/table/tbody/tr[1]/td[1]/table/tbody/tr/td[1]/table/tbody/tr/td/table/tbody/tr/td[5]/div"))
				.click();
		Actions action = new Actions(driver);

		Actions builder = new Actions(driver);
		WebElement we2 = driver.findElement(By
				.xpath(".//*[@id='link3']/strong"));

		Action mouseOver = builder.moveToElement(we2).build();
		mouseOver.perform();

		WebElement we1 = driver.findElement(By
				.xpath(".//*[@id='menuItemHilite32']"));
		action.moveToElement(we1).click().build().perform();
		// driver.findElement(By.id(".//*[@id='menuItemHilite32']")).click();
	}

	@AfterTest
	public void afterTest() throws Exception {
		driver.quit();
	}
}

