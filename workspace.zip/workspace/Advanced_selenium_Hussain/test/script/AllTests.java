package script;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ Anna_Junit_Chrome.class, Anna_Junit_FF.class,
		Anna_Junit_IE.class, Wiki_Junit_Chrome.class, Wiki_Junit_FF.class,
		Wiki_Junit_IE.class })
public class AllTests {

}
