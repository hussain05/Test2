package script;



	import java.util.List;
import java.util.concurrent.TimeUnit;

	import org.junit.*;

	import static org.junit.Assert.*;

	import org.openqa.selenium.*;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.firefox.FirefoxDriver;
	import org.openqa.selenium.interactions.Action;
	import org.openqa.selenium.interactions.Actions;

	import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

	public class Nick  {
		private WebDriver driver;
		private String baseUrl;
		private boolean acceptNextAlert = true;
		private StringBuffer verificationErrors = new StringBuffer();

		@Before
		public void setUp() throws Exception {
			driver = new FirefoxDriver(); 
										

			baseUrl = "www.nick.com";
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		}

		@Test
		public void testAnnaDeanW() throws Exception {
			driver.get("http://www.nick.com");
			driver.findElement(By.xpath(".//*[@id='balaCloseImage']")).click();
			List<WebElement> we = driver.findElements(By.xpath("html/body/div[5]/div/div/div[1]/div/div[1]/div/div/div/a/span/span[3]/img"));
			System.out.println(we.size());
		}

		@After
		public void tearDown() throws Exception {
			driver.quit();
		}

		private boolean isElementPresent(By by) {
			try {
				driver.findElement(by);
				return true;
			} catch (NoSuchElementException e) {
				return false;
			}
		}

		private boolean isAlertPresent() {
			try {
				driver.switchTo().alert();
				return true;
			} catch (NoAlertPresentException e) {
				return false;
			}
		}

		private String closeAlertAndGetItsText() {
			try {
				Alert alert = driver.switchTo().alert();
				String alertText = alert.getText();
				if (acceptNextAlert) {
					alert.accept();
				} else {
					alert.dismiss();
				}
				return alertText;
			} finally {
				acceptNextAlert = true;
			}
		}
	}

