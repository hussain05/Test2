package script;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

public class Hussain_Question1_RMP {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	@BeforeTest
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"test\\resources\\chromedriver.exe");

		driver = new ChromeDriver();

		baseUrl = "http://www.ratemyprofessors.com/";
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void Run_test() throws Exception {
		driver.get(baseUrl);
		// Close cookie notice
		driver.findElement(By.xpath(".//*[@id='cookie_notice']/a[1]")).click();
		driver.findElement(By.xpath(".//*[@id='findProfessorOption']/span"))
				.click();
		driver.findElement(By.xpath(".//*[@id='searchProfessorName']"))
				.sendKeys("a");
		driver.findElement(By.xpath(".//*[@id='prof-name-btn']")).click();
		driver.findElement(
				By.xpath("//div[@id='filterBox']/div[2]/div[2]/div/form[4]/span/span"))
				.click();

		driver.findElement(
				By.xpath(".//*[@id='filterBox']/div[2]/div[2]/div/form[4]/span/span[2]/span/span[3]"))
				.click();
		driver.findElement(
				By.xpath(".//*[@id='filterBox']/div[2]/div[2]/div/form[2]/span[1]/span[1]"))
				.click();

		driver.findElement(
				By.xpath(".//*[@id='filterBox']/div[2]/div[2]/div/form[2]/span[1]/span[2]/span/span[6]"))
				.click();
		driver.findElement(
				By.xpath(".//*[@id='searchResultsBox']/div[1]/div[1]/div[5]/a[1]"))
				.click();

		String professor_name = driver
				.findElement(
						By.xpath(".//*[@id='searchResultsBox']/div[2]/ul/li[1]/a/span[2]/span[1]"))
				.getText();

		System.out.println("21st Professor name: " + professor_name);

	}

	@AfterTest
	public void tearDown() throws Exception {
		driver.quit();
	}

}
