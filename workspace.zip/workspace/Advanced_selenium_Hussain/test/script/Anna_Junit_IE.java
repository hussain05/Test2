package script;

import java.util.concurrent.TimeUnit;

import org.junit.*;

import static org.junit.Assert.*;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

public class Anna_Junit_IE {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.ie.driver","test\\resources\\IEDriverServer.exe"); //for IE
		//WebDriver driver = new ChromeDriver(); //for IE
		 driver = new InternetExplorerDriver();
		driver = new ChromeDriver();

		baseUrl = "https://www.annauniv.edu/";
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testAnnaDeanW() throws Exception {
		driver.get("https://www.annauniv.edu/");
		driver.findElement(
				By.xpath("html/body/table/tbody/tr[1]/td[1]/table/tbody/tr/td[1]/table/tbody/tr/td/table/tbody/tr/td[5]/div"))
				.click();
		Actions action = new Actions(driver);

		Actions builder = new Actions(driver);
		WebElement we2 = driver.findElement(By
				.xpath(".//*[@id='link3']/strong"));

		Action mouseOver = builder.moveToElement(we2).build();
		mouseOver.perform();

		WebElement we1 = driver.findElement(By
				.xpath(".//*[@id='menuItemHilite32']"));
		action.moveToElement(we1).click().build().perform();
		// driver.findElement(By.id(".//*[@id='menuItemHilite32']")).click();
	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
