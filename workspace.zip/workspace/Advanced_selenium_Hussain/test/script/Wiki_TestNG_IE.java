
package script;



import com.thoughtworks.selenium.Selenium;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;




public class Wiki_TestNG_IE {
	private Selenium selenium;
WebDriver driver;
	@BeforeTest
	public void setUp() throws Exception {
		
		
	//	System.setProperty("webdriver.chrome.driver","test\\resources\\chromedriver.exe"); //for chrome
	System.setProperty("webdriver.ie.driver","test\\resources\\IEDriverServer.exe"); //for IE
		//WebDriver driver = new ChromeDriver(); //for IE
		 driver = new InternetExplorerDriver();
		String baseUrl = "https://www.wikipedia.org/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);  //For RC commands below; better remove if using PURE webdriver code
	}

	@Test
	public void testWiki_wb() throws Exception {
		selenium.open("");
		selenium.click("css=strong");
		selenium.waitForPageToLoad("60000");
		selenium.type("id=searchInput", "selenium");
		selenium.click("id=searchButton");
		selenium.waitForPageToLoad("60000");
	
		Assert.assertEquals("Selenium - Wikipedia, the free encyclopedia", selenium.getTitle());
		Assert.assertEquals("Selenium", selenium.getText("id=firstHeading"));
		//assertEquals(By.id("firstHeading").toString(),"Selenium");
	}

	@AfterTest
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
