package script;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

public class Hussain_Question2_MTV {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	@BeforeTest
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"test\\resources\\chromedriver.exe");

		driver = new ChromeDriver();

		baseUrl = "http://www.mtv.com/";
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void Run_test() throws Exception {
		driver.get(baseUrl);
		// Close cookie notice below using RED CLOSE BUTTON
		driver.findElement(By.xpath(".//*[@id='balaCloseImage']")).click();
		// MOUSEOVER SHOWS
		

		Actions builder = new Actions(driver);
		WebElement we2 = driver.findElement(By
				.xpath(".//*[@id='header']/div/div[1]/div[2]/div/ul/li[1]/a"));

		Action mouseOver = builder.moveToElement(we2).build();
		mouseOver.perform();

		// MOUSEOVER SHOWS A-Z
		

		Actions builder1 = new Actions(driver);
		WebElement we3 = driver
				.findElement(By
						.xpath(".//*[@id='header']/div/div[1]/div[2]/div/ul/li[1]/div/div/div/div/div[1]/a[2]"));

		Action mouseOver1 = builder.moveToElement(we3).build();
		mouseOver1.perform();

		driver.findElement(
				By.xpath(".//*[@id='header']/div/div[1]/div[2]/div/ul/li[1]/div/div/div/div/div[1]/a[2]"))
				.click();
		// Thread.sleep(5000);
		// CLOSE CAROUSEL
		

		Actions builder2 = new Actions(driver);
		WebElement we4 = driver.findElement(By
				.xpath(".//*[@id='t3_lc']/div/div/div/ul/li[1]/a/div/img"));

		Action mouseOver2 = builder.moveToElement(we3).build();
		mouseOver2.perform();

		while (!isElementPresent(By.xpath(".//*[@id='labelR']/span"))) {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("window.scrollBy(0,250)", ""); // Scroll down
		}
		String shows;
		driver.findElement(By.xpath(".//*[@id='labelR']/span")).click();
		for (int i = 1; i <= 20; i++) {
			shows = driver.findElement(
					By.xpath(".//*[@id='collapseR']/div/div/div/ul/li[" + i
							+ "]/a")).getText();
			System.out.println(shows);
		}

	}

	@AfterTest
	public void tearDown() throws Exception {
		driver.quit();
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

}
