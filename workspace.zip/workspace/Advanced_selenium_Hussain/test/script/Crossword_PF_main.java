package script;

import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.http.conn.ssl.BrowserCompatHostnameVerifier;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

public class Crossword_PF_main {

	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	Crossword_PageFactory crossword_object; // create an object of
											// pagefactory class
	String browser, searchVal, URL;

	@Before
	public void setUp() throws Exception {
		File file = new File("test\\resources\\properties\\Crossword_Properties.properties");
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();

		// load props file

		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		browser = prop.getProperty("browser");
		searchVal = prop.getProperty("search_Val");
		URL = prop.getProperty("URL");

		if (browser.equals("Firefox"))
			driver = new FirefoxDriver();
		else

		{
			System.setProperty("webdriver.chrome.driver",
					"test\\resources\\chromedriver.exe");

			driver = new ChromeDriver();
		}
		baseUrl = URL;
		// driver.manage().timeouts().implicitlyWait(, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		crossword_object = PageFactory.initElements(driver,
				Crossword_PageFactory.class);
	}

	@Test
	public void testCrosswordJunitFF() throws Exception {
		driver.get(URL);
		crossword_object._searchField.sendKeys(searchVal);
		crossword_object._searchButton.click();
	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
