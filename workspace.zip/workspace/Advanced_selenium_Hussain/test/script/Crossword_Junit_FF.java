package script;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;

import mx4j.log.Log;

import org.junit.*;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Crossword_Junit_FF {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://www.crossword.in/";
 //   driver.manage().timeouts().implicitlyWait(, TimeUnit.SECONDS);
    driver.manage().window().maximize();
  }

  @Test
  public void testCrosswordJunitFF() throws Exception {
    driver.get(baseUrl);
    driver.findElement(By.id("search-input")).clear();
    driver.findElement(By.id("search-input")).sendKeys("cricket");
    driver.findElement(By.cssSelector("input.search-go")).click();
    driver.findElement(By.xpath(".//*[@id='search-results']/div[2]/div[3]/span[2]/a[3]")).click();
    Thread.sleep(5000);
    String value, value2;
    int value_int, value_int2, results_count;
    results_count = Integer.parseInt(driver.findElement(By.xpath(".//*[@id='search-results']/div[2]/div[1]/span[1]")).getText().replaceAll("[^0-9]", ""));
    while(!isElementPresent(By.xpath(".//*[@id='search-result-items']/li["+results_count+"]/div/div[2]/span[3]/span/span")))
    {
    	JavascriptExecutor jse = (JavascriptExecutor)driver;
    	jse.executeScript("window.scrollBy(0,250)", ""); //Scroll down
    	//Thread.sleep(2000);
    }
    
    for(int i=1;i<results_count;i++)
    {
    	if(isElementPresent(By.xpath(".//*[@id='search-result-items']/li["+i+"]/div/div[2]/span[3]/span[3]/span")))
    	{
    		value = driver.findElement(By.xpath(".//*[@id='search-result-items']/li["+i+"]/div/div[2]/span[3]/span[3]/span")).getText().replaceAll("[^0-9]", "");
        	
    	}
    	else
    	{
    		value = driver.findElement(By.xpath(".//*[@id='search-result-items']/li["+i+"]/div/div[2]/span[3]/span/span")).getText().replaceAll("[^0-9]", "");   
    	}
    	
    	if(isElementPresent(By.xpath(".//*[@id='search-result-items']/li["+(i+1)+"]/div/div[2]/span[3]/span[3]/span")))
    	{
    		value2 = driver.findElement(By.xpath(".//*[@id='search-result-items']/li["+(i+1)+"]/div/div[2]/span[3]/span[3]/span")).getText().replaceAll("[^0-9]", "");  
    	}
        	
    	
    	else
    	{
    		value2 = driver.findElement(By.xpath(".//*[@id='search-result-items']/li["+(i+1)+"]/div/div[2]/span[3]/span/span")).getText().replaceAll("[^0-9]", "");  
    	}
    	
    	
    	value_int = Integer.parseInt(value);
    	value_int2 = Integer.parseInt(value2);
    	
    	
    	//value_int = Integer.parseInt(value);
    	//System.out.println(value);
    	if(value_int<value_int2)
    	{
    		System.out.println("FAILED as value of product "+i+ "(" +value_int+ ") is less than value of product "+(i+1)+" ("+value_int2+")");
    		
    	}
    	/*Actions action;
    	action = new Actions(driver);
    	action.sendKeys(Keys.DOWN);*/
    	
    }
    
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
