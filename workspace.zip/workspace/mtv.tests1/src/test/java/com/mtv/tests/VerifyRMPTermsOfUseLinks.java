package com.mtv.tests;

import org.testng.annotations.Test;

import com.mtv.common.Base;
import com.mtv.constants.LocatorTypes;
import com.mtv.constants.RMPConstants;
import com.mtv.constants.Waits;
import com.mtv.interact.WebInteract;
import com.mtv.pageObjects.RMPTermsOfUse;
import com.mtv.util.CommonMethods;
import com.mtv.util.ExplicitWaits;

public class VerifyRMPTermsOfUseLinks extends Base{
	
	CommonMethods method;
	RMPTermsOfUse TermsOfUseObject;
	WebInteract webInteract;
	ExplicitWaits wait;
	
	@Test
	public void testLinks()
	{
		method = new CommonMethods();
		if(getDeviceType().equalsIgnoreCase("desktop"))
		{
			
			webInteract = new WebInteract(getWebDriver());
			TermsOfUseObject = new RMPTermsOfUse(getWebDriver());
			wait = new ExplicitWaits(getWebDriver());
		}
		
		else
		{
			
			webInteract = new WebInteract(getAndroidDriver());
			TermsOfUseObject = new RMPTermsOfUse(getAndroidDriver());
			wait = new ExplicitWaits(getAndroidDriver());
		}
		
		CommonMethods.setPropertyFileName(RMPConstants.TermsOfUsePropFileName.value());
		openUrl(RMPConstants.TermsOfUseURL.value());
		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("cookie"),Waits.LONGWAITSECONDS.value());
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("cookie")).click();
		TermsOfUseObject.checkLinks();
	}
	
}

