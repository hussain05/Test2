package com.mtv.constants;

public enum CompassConstants {
	
	CompassLoginUrl("https://compass.lntinfotech.com/digite/Secured"),
	Username("10611983"),
	Password("8C@dbury"),
	CompassPropFilename("Compass");
	
	private final String value;

	private CompassConstants(String value) {
		this.value = value;
	}

	public String value() {
		return value;
	}

}