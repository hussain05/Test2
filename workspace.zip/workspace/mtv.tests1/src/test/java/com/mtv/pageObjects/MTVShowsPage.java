package com.mtv.pageObjects;

import java.util.List;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.mtv.constants.LocatorTypes;
import com.mtv.constants.Waits;
import com.mtv.interact.WebInteract;
import com.mtv.util.CommonMethods;
import com.mtv.util.ExplicitWaits;
import com.mtv.util.SoftAssertions;

public class MTVShowsPage {

	WebDriver driverWeb;
	AndroidDriver driverAndroid;
	ExplicitWaits wait;
	CommonMethods method;
	WebInteract webInteract;
	SoftAssertions sa;

	public MTVShowsPage(WebDriver driver) {
		this.driverWeb = driver;
		wait = new ExplicitWaits(driver);
		webInteract = new WebInteract(driver);
	}

	public MTVShowsPage(AndroidDriver driver) {
		this.driverAndroid = driver;
		wait = new ExplicitWaits(driver);
		webInteract = new WebInteract(driver);
	}

	public void verifyShowOrder(){

		method = new CommonMethods();

		/*wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("bala"), Waits.MEDIUMWAITSECONDS.value());

		if(webInteract.isElementPresentCheck(LocatorTypes.XPATH.value(),method.getLocator("bala")))
		{*/

		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("bala"),Waits.MEDIUMWAITSECONDS.value());
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("bala")).click();
		//}

		webInteract.scrollDownToElement(webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("filters")));
		
		List<WebElement> alphabetFilter = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("alphabetFilter"));
		for(WebElement af: alphabetFilter)
		{
			String temp = af.getAttribute("class"); 

			if(!temp.equals("accordion-toggle disabled")) //to check whether the filter is disabled
			{
				List<WebElement> showsList;
				af.click();
				
			
				if(af.getText().equals("#"))
				{
					showsList = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("showsList-hash"));
					
				}
				else
				{
					showsList = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("showsList-"+af.getText()));
				}
				//webInteract.scrollDownToElement1(showsList.get(0));
				for(WebElement SL : showsList)
				{
					
					if(!SL.getText().startsWith(af.getText()))
					{
						System.out.println("Show \"" +SL.getText()+ "\" does not belong to this filter as it does not start with " +af.getText());
					}
				}                

			}

		}
	}
}

