package com.mtv.tests;

import org.testng.annotations.Test;

import com.mtv.common.Base;
import com.mtv.constants.MTVConstants;
import com.mtv.pageObjects.MTVShowsPage;
import com.mtv.util.CommonMethods;

public class VerifyMTVShowsOrder extends Base {
	
@Test
	
	public void testTVShowsOrder() {
		
		MTVShowsPage TVShowsObject;
		CommonMethods.setPropertyFileName(MTVConstants.TVShowsPropFile.value());
		
		if (getDeviceType().equalsIgnoreCase("desktop")) {

			TVShowsObject = new MTVShowsPage(getWebDriver());
		}

		else {

			TVShowsObject = new MTVShowsPage(getAndroidDriver());
		}

		openUrl(MTVConstants.TVShowsUrl.value());
		
			TVShowsObject.verifyShowOrder();
		
	}

}
