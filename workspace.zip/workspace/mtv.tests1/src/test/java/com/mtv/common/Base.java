package com.mtv.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import junit.framework.TestCase;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

@SuppressWarnings("unused")
public class Base {

	private static WebDriver driverWeb;
	private static AndroidDriver driverAndroid;
	private static String deviceType;

	/*
	 * @BeforeSuite public void beforeMethod() { System.out.println(
	 * "*****Before Test*****"); driver.manage().window().maximize();
	 * 
	 * }
	 * 
	 * @AfterSuite public void afterMethod() { System.out.println(
	 * "*****After Test*****"); }
	 */

	public void setWebDriver(WebDriver driver) {
		driverWeb = driver;
		maximizeWindow();

	}

	public WebDriver getWebDriver() {
		return driverWeb;
	}

	public void setAndroidDriver(AndroidDriver driver) {
		driverAndroid = driver;
	}

	public AndroidDriver getAndroidDriver() {
		return driverAndroid;
	}

	public void maximizeWindow() {
		driverWeb.manage().window().maximize();

	}

	public static void openUrl(String url) {
		if (deviceType.equalsIgnoreCase("desktop"))
			driverWeb.get(url);
		else
			driverAndroid.get(url);
	}

	public static String getCurrentUrl() {
		if (deviceType.equalsIgnoreCase("desktop"))
			return driverWeb.getCurrentUrl();
		else
			return driverAndroid.getCurrentUrl();

	}

	public void setDeviceType(String device) {
		deviceType = device;
	}

	public static String getDeviceType() {
		return deviceType;
	}

	public static void navigateBack()
	{
		if(deviceType.equalsIgnoreCase("desktop"))
		{
			driverWeb.navigate().back();
		}
		else
		{
			driverAndroid.navigate().back();
		}
	}
	
	public static void pause()
	{
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
