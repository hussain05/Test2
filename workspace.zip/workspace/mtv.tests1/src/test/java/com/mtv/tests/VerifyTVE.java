package com.mtv.tests;

import org.testng.annotations.Test;

import com.mtv.common.Base;
import com.mtv.constants.MTVConstants;
import com.mtv.pageObjects.TVE;
import com.mtv.util.CommonMethods;

public class VerifyTVE extends Base{
	
@Test
	
	public void testTVE() {
		
		TVE TVEObject;
		CommonMethods.setPropertyFileName(MTVConstants.ShowAreYouTheOnePagePropFile.value());
		
		if (getDeviceType().equalsIgnoreCase("desktop")) {

			TVEObject = new TVE(getWebDriver());
		}

		else {

			TVEObject = new TVE(getAndroidDriver());
		}

		openUrl(MTVConstants.ShowAreYouTheOneUrl.value());
		
			TVEObject.openLockedEpisodes();
		
	}

}


