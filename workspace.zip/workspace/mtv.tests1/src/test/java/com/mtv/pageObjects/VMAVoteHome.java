package com.mtv.pageObjects;

import java.util.List;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.mtv.common.Base;
import com.mtv.constants.LocatorTypes;
import com.mtv.constants.VMAConstants;
import com.mtv.interact.WebInteract;
import com.mtv.util.CommonMethods;
import com.mtv.util.ExplicitWaits;
import com.mtv.util.SoftAssertions;

public class VMAVoteHome {
	WebDriver driverWeb;
	AndroidDriver driverAndroid;
	ExplicitWaits wait;
	CommonMethods method = new CommonMethods();
	WebInteract webInteract;
	SoftAssertions sa = new SoftAssertions();

	public VMAVoteHome(WebDriver driver) {
		this.driverWeb = driver;
		wait = new ExplicitWaits(driver);
		webInteract = new WebInteract(driver);
	}

	public VMAVoteHome(AndroidDriver driver) {
		this.driverAndroid = driver;
		wait = new ExplicitWaits(driver);
		webInteract = new WebInteract(driver);
	}

	public void VMALogin() {
		// webInteract.getElement(LocatorTypes.XPATH.value(),
		// method.getLocator("passwordField")).sendKeys(VMAConstants.VMAPassword.value());
		// webInteract.getElement(LocatorTypes.XPATH.value(),
		// method.getLocator("submitButton")).click();
		Base.pause();
		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("cookie"), 10);
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("cookie")).click();
		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("temp"), 10);
	}

	public void verifyVotingCategoriesExpansion() {
		Base.pause();
		Base.pause();
		List<WebElement> votingCategories = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("votingCategories"));
		int i = 1;
		for (WebElement we : votingCategories) {
			if (i != 1) {
				we.click(); // expand category other than first category as it
							// is already expanded on launch
			}
			wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("votingCategory" + i), 10);
			List<WebElement> nominees = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("votingCategory" + i));
			if (i != 7)
				sa.assertTrue(nominees.size() == 6, " Fail");
			else
				sa.assertTrue(nominees.size() == 7, " Fail");
			List<WebElement> voteButtons = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("voteButtonsList" + i));
			for (WebElement vote : voteButtons) {
				webInteract.scrollDownToElement(vote);
				Base.pause();
				vote.click();
				Base.pause();
				sa.assertEquals(webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("modalLoginText")).getText(), "LOG IN TO CAST YOUR VOTE");
				webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("modalCloseButton")).click();
			}
			System.out.println(we.getText());
			Base.pause();
			we.click();// collapse the category
			Base.pause();
			i++;
		}
	}

	public void verifyVMAEmailLogin() {
		Base.pause();
		// webInteract.scrollDownToElement(LocatorTypes.XPATH.value(),
		// ".//*[@id='social']/div/ul");
		JavascriptExecutor jse = (JavascriptExecutor) driverWeb;
		jse.executeScript("window.scrollBy(0,2500)", "");
		jse.executeScript("window.scrollBy(0,2500)", "");// Scroll down
		Base.pause();
		Base.pause();
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("loginLink")).click();
		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("modalEmailField"), 10);
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("modalEmailField")).sendKeys(VMAConstants.VMAVoteInvalidEmail.value());
		Assert.assertTrue(webInteract.isElementPresentCheck(LocatorTypes.XPATH.value(), method.getLocator("modalLoginButton")), "Login button should be present");
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("modalLoginButton")).click();
		Assert.assertTrue(webInteract.isElementPresentCheck(LocatorTypes.XPATH.value(), method.getLocator("modalInvalidEmailValidation")));
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("modalEmailField")).clear();
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("modalEmailField")).sendKeys(VMAConstants.VMAVoteEmail.value());
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("modalLoginButton")).click();
		Assert.assertTrue(webInteract.isElementPresentCheck(LocatorTypes.XPATH.value(), method.getLocator("modalAgreeValidation")));
		Base.pause();
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("modalAgreeCheckbox")).click();
		Base.pause();
		Base.pause();
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("modalLoginButton")).click();
		Base.pause();
		Assert.assertEquals(webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("logoutLink")).getText(), "LOG OUT");
		Base.pause();
		Base.pause();
		 
		jse.executeScript("window.scrollBy(0,2500)", "");
		jse.executeScript("window.scrollBy(0,2500)", "");
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("logoutLink")).click();
		Base.pause();
		
		Assert.assertEquals(webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("loginLink")).getText(), "LOG IN");
		
	}

	@SuppressWarnings("unused")
	public void verifyVote() {
		if (!isLoggedIn()) {
			login();
		}
		Base.pause();
		Base.pause();
		if (getVoteCount() != 10) {
			webInteract.scrollUpToElement(LocatorTypes.XPATH.value(), method.getLocator("temp"));
			List<WebElement> votingCategories = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("votingCategories"));
			
			for (WebElement we : votingCategories) {
				
				List<WebElement> voteButtons = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("voteButtonsList"));
				System.out.println(voteButtons.size());
				voteButtons.get(1).click();
				Base.pause();
				List<WebElement> votedList = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("votedList"));
				Assert.assertEquals(getVoteCount(), votedList.size() - 1);
				
			}
		} else {
			List<WebElement> votedList = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("votedList"));
			Assert.assertEquals(getVoteCount(), votedList.size());
			System.out.println("Pass");
		}
	}

	public int getVoteCount() {
		webInteract.scrollDownToElement(LocatorTypes.XPATH.value(), method.getLocator("temp"));
		return Integer.parseInt(webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("voteCount")).getText());
	}

	public boolean isLoggedIn() {
		return webInteract.isElementPresentCheck(LocatorTypes.XPATH.value(), method.getLocator("logoutLink"));
	}

	public void login() {
		/*JavascriptExecutor jse = (JavascriptExecutor) driverWeb;
		jse.executeScript("window.scrollBy(0,2500)", "");
		jse.executeScript("window.scrollBy(0,2500)", "");*/// Scroll down
		webInteract.scrollDownToElement(LocatorTypes.XPATH.value(), method.getLocator("loginLink"));
		webInteract.scrollDownToElement(LocatorTypes.XPATH.value(), method.getLocator("loginLink"));
		Base.pause();
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("loginLink")).click();
		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("modalEmailField"), 10);
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("modalEmailField")).sendKeys(VMAConstants.VMAVoteEmail.value());
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("modalAgreeCheckbox")).click();
		Base.pause();
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("modalLoginButton")).click();
		Base.pause();
	}
}
