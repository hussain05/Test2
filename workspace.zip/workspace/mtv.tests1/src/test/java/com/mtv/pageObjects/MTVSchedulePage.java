package com.mtv.pageObjects;

import io.appium.java_client.android.AndroidDriver;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.mtv.constants.LocatorTypes;
import com.mtv.constants.Waits;
import com.mtv.interact.WebInteract;
import com.mtv.util.CommonMethods;
import com.mtv.util.ExplicitWaits;
import com.mtv.util.SoftAssertions;

public class MTVSchedulePage {

	WebDriver driverWeb;
	AndroidDriver driverAndroid;
	ExplicitWaits wait;
	CommonMethods method;
	WebInteract webInteract;
	SoftAssertions sa;

	public MTVSchedulePage(WebDriver driver) {
		this.driverWeb = driver;
		wait = new ExplicitWaits(driver);
		webInteract = new WebInteract(driver);
	}

	public MTVSchedulePage(AndroidDriver driver) {
		this.driverAndroid = driver;
		wait = new ExplicitWaits(driver);
		webInteract = new WebInteract(driver);
	}

	public void verifyTVSchedule() throws ParseException {

		method = new CommonMethods();
		sa = new SoftAssertions();
		boolean result;
		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("bala"),Waits.MEDIUMWAITSECONDS.value());
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("bala")).click();

		for (int dateCount = 1; dateCount <= 14; dateCount++) {
			int count = 0;

			// COLLAPSE the first item if it is expanded
			if (webInteract.isElementPresentCheck(LocatorTypes.XPATH.value(),
					method.getLocator("firstItem"))) {
				webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("firstItem"))
						.click();
			}

			List<WebElement> timeElementsList = webInteract.getElements(
					LocatorTypes.XPATH.value(), method.getLocator("timeElements"));
			List<WebElement> titleElementsList = webInteract.getElements(
					LocatorTypes.XPATH.value(), method.getLocator("titleElements"));

			Map<String, String> schedule = new HashMap<String, String>();
			Map<Integer, Date> temp = new HashMap<Integer, Date>();
			SimpleDateFormat format = new SimpleDateFormat("h:mma"); // Parse
																		// date/time
																		// in
																		// format
																		// retrieved
																		// from
																		// webpage
																		// 6:30pm
			Date a;

			String temp1, temp2;
			int j = 0;

			for (int i = 0; i < timeElementsList.size(); i++) {

				schedule.put(timeElementsList.get(i).getText(),
						titleElementsList.get(i).getText());

				a = format.parse(timeElementsList.get(i).getText()
						.toUpperCase()); // convert pm--> PM

				if (i != 0) {
					temp1 = timeElementsList.get(i).getText()
							.replaceAll("[^A-Za-z]+", "");
					temp2 = timeElementsList.get(i - 1).getText()
							.replaceAll("[^A-Za-z]+", "");
					if (!temp1.equals(temp2))
						j = i;
				}

				temp.put(new Integer(i), a); // add dates to given set before
												// 12am

			}
			Integer key;
			Iterator<Integer> itr = temp.keySet().iterator();
			while (itr.hasNext()) {
				key = itr.next();

				// System.out.println("Final " + temp.get(key));

				if (key != 0) {
					result = temp.get(key).compareTo(temp.get(key - 1)) >= 0
							|| key == j;
					if (result == false)
						count++;
					sa.assertTrue(
							result,
							"Time not in ascending order for "
									+ temp.get(key)
									+ " and "
									+ temp.get(key - 1)
									+ " for Date "
									+ webInteract.getElement(LocatorTypes.XPATH.value(),
											method.getLocator("currentDate"))
											.getText());
				}

			}

			if (count == 0) {

				System.out.println("Timings in proper ascending order for "
						+ webInteract.getElement(LocatorTypes.XPATH.value(),
								method.getLocator("currentDate")).getText());
			} else
				System.out.println("Timings not in proper ascending order for "
						+ webInteract.getElement(LocatorTypes.XPATH.value(),
								method.getLocator("currentDate")).getText());

			if (dateCount != 14) // As it will be last date, no next date will
									// be available
			{
				webInteract.getElement(LocatorTypes.XPATH.value(),
						method.getLocator("nextDateButton")).click();

				wait.waitforElementTextChange(method.getLocator("currentDate"));

			}

		}
	}
}
