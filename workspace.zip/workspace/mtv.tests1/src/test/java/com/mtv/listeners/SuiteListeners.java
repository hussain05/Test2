package com.mtv.listeners;

import io.appium.java_client.android.AndroidDriver;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.ISuite;
import org.testng.ISuiteListener;

import com.mtv.common.Base;
import com.mtv.util.SetCapabilities;

public class SuiteListeners extends Base implements ISuiteListener {

	@Override
	public void onStart(ISuite suite) {

		if(suite.getParameter("Device").equalsIgnoreCase("desktop"))
		{
			setDeviceType("desktop");
		switch (suite.getParameter("Browser")) {
		case "Chrome":
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-extensions");
			setWebDriver(new ChromeDriver(options));
			break;
		case "IE":
			setWebDriver(new InternetExplorerDriver());
			break;
		case "Firefox":
			setWebDriver(new FirefoxDriver());
			break;
		default:
			System.out.println("Browser type is not supported");
			break;

		}
		}
		else
		{
			setDeviceType("mobile");
			SetCapabilities s = new SetCapabilities();
			try {
				setAndroidDriver(new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),s.SetCapabilitiesAndroid()));
			} catch (MalformedURLException e) {
				
				e.printStackTrace();
			}
		}

	}

	@Override
	public void onFinish(ISuite suite) {
		System.out.println("================= Finished ================");
		if(suite.getParameter("Device").equalsIgnoreCase("desktop"))
		{
		getWebDriver().quit();
		}
		else
		{
			getAndroidDriver().quit();
		}
	}

}