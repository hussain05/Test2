package com.mtv.tests;

import java.text.ParseException;
import org.testng.annotations.Test;

import com.mtv.common.Base;
import com.mtv.constants.MTVConstants;
import com.mtv.pageObjects.MTVSchedulePage;
import com.mtv.util.CommonMethods;

public class VerifyMTVScheduleOrder extends Base {

	@Test
	
	public void testTVSchedule() {
		
		MTVSchedulePage TVScheduleObject;
		CommonMethods.setPropertyFileName(MTVConstants.TVSchedulePagePropFile.value());
		
		if (getDeviceType().equalsIgnoreCase("desktop")) {

			TVScheduleObject = new MTVSchedulePage(getWebDriver());
		}

		else {

			TVScheduleObject = new MTVSchedulePage(getAndroidDriver());
		}

		openUrl(MTVConstants.TVSchedulePageUrl.value());
		try {
			TVScheduleObject.verifyTVSchedule();
		} catch (ParseException e) {

			e.printStackTrace();
		}
	}

}
