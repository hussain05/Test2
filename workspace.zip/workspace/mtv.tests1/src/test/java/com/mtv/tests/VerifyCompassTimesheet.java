package com.mtv.tests;

import org.testng.annotations.Test;

import com.mtv.common.Base;
import com.mtv.constants.CompassConstants;
import com.mtv.pageObjects.CompassTimesheet;
import com.mtv.util.CommonMethods;

public class VerifyCompassTimesheet extends Base {
	CompassTimesheet timesheetObject;

	@Test(priority=1)
	public void CompassLogin() {
		CommonMethods.setPropertyFileName(CompassConstants.CompassPropFilename.value());
		openUrl(CompassConstants.CompassLoginUrl.value());
		if (getDeviceType().equalsIgnoreCase("desktop")) {
			timesheetObject = new CompassTimesheet(getWebDriver());
		} else {
			timesheetObject = new CompassTimesheet(getAndroidDriver());
		}
		timesheetObject.loginCompass();
		
	}
	
	@Test (dependsOnMethods={"CompassLogin"})
	public void FillTimeSheet()
	{
		timesheetObject.fillTimesheet();
	}
	
}
