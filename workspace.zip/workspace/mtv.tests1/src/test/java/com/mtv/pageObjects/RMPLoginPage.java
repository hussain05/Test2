package com.mtv.pageObjects;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.mtv.common.Base;
import com.mtv.constants.LocatorTypes;
import com.mtv.interact.WebInteract;
import com.mtv.util.CommonMethods;
import com.mtv.util.SoftAssertions;

public class RMPLoginPage {

	CommonMethods method = new CommonMethods();
	SoftAssertions sa;
	WebInteract webInteract;

	public RMPLoginPage(WebDriver driver) {

		webInteract = new WebInteract(driver);
		sa = new SoftAssertions();
	}

	public RMPLoginPage(AndroidDriver driver) {

		webInteract = new WebInteract(driver);
		sa = new SoftAssertions();
	}

	public void verifyLogin(String i, String result, String userName,
			String password) throws Exception {
		

		if (verifyUserLoggedIn()) {
			webInteract.getElement(LocatorTypes.XPATH.value(),
					method.getLocator("loginButtonHeader")).click();
			webInteract.getElement(LocatorTypes.XPATH.value(),
					method.getLocator("logoutButtonHeader")).click();
			webInteract.getElement(LocatorTypes.XPATH.value(),
					method.getLocator("loginButtonHeader")).click();
		}

		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("emailField"))
				.clear();

		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("emailField"))
				.sendKeys(userName);

		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("passwordField"))
				.sendKeys(password);

		if (Base.getCurrentUrl().equals(
				"http://www.ratemyprofessors.com/member/loginFail")) {
			webInteract.getElement(LocatorTypes.XPATH.value(),
					method.getLocator("loginButtonFail")).click();

		}

		else {

			webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("loginButton"))
					.click();

		}
		if (result.equals("invalid")) {
			try {
				Assert.assertEquals(Base.getCurrentUrl(),
						"http://www.ratemyprofessors.com/member/loginFail");
				System.out.println("Test case passed for combination " + i);
			} catch (AssertionError e) {
				System.out.println("Test case failed for combination " + i);
				throw e;
			}
		} else {
			try {
				Assert.assertEquals(Base.getCurrentUrl(),
						"http://www.ratemyprofessors.com/");
				System.out.println("Test case passed for combination " + i);
			} catch (AssertionError e) {
				System.out.println("Test case failed for combination " + i);
				throw e;
			}
		}

	}

	private boolean verifyUserLoggedIn() {

		if (webInteract
				.getElement(LocatorTypes.XPATH.value(), method.getLocator("loginButtonHeader"))
				.getText().equals("LOG IN / SIGN UP"))
			return false;

		return true;
	}

}
