package com.mtv.util;

import java.util.Properties;

import org.openqa.selenium.By;
import com.mtv.common.Base;

public class CommonMethods {

	Properties prop;
	static public String propertyFileName; 
	

	public static void setPropertyFileName(String PropertyFileName) {
		propertyFileName = PropertyFileName;
	}

	public String getPropertyFileName() {
		return propertyFileName;
	}

	public String getLocator(String locatorName) {

		prop = ReadProperties.readPropertyFile(getPropertyFileName(),
				Base.getDeviceType());
		return prop.getProperty(locatorName);

	}

	public By getBy(String locatorType, String locator) {
		By by;
		switch (locatorType) {

		case "xpath":
			by = By.xpath(locator);
			break;

		case "id":
			by = By.id(locator);
			break;

		case "css":
			by = By.cssSelector(locator);
			break;

		case "class":
			by = By.className(locator);
			break;

		case "tag":
			by = By.tagName(locator);
			break;

		default:
			by = null;
			break;

		}
		return by;

	}

}
