package com.mtv.pageObjects;

import java.util.List;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.mtv.constants.CompassConstants;
import com.mtv.constants.LocatorTypes;
import com.mtv.interact.WebInteract;
import com.mtv.util.CommonMethods;
import com.mtv.util.SoftAssertions;

public class CompassTimesheet {
	CommonMethods method = new CommonMethods();
	SoftAssertions sa;
	WebInteract webInteract;

	public CompassTimesheet(WebDriver driver) {

		webInteract = new WebInteract(driver);
		sa = new SoftAssertions();
	}

	public CompassTimesheet(AndroidDriver driver) {

		webInteract = new WebInteract(driver);
		sa = new SoftAssertions();
	}
	
	public void loginCompass()
	{
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("username")).sendKeys(CompassConstants.Username.value());
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("password")).sendKeys(CompassConstants.Password.value());
		
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("loginButton")).click();
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
		Assert.assertTrue(webInteract.isElementPresentCheck(LocatorTypes.XPATH.value(), method.getLocator("timesheet")));
	}
	
	public void fillTimesheet()
	{
		webInteract.hoverOnElement(LocatorTypes.XPATH.value(),method.getLocator("timesheet"));
		webInteract.hoverOnElement(LocatorTypes.XPATH.value(),method.getLocator("timeTracking"));
		webInteract.getElement(LocatorTypes.XPATH.value(),method.getLocator("timeTracking")).click();
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
		
		//webInteract.hoverOnElement(LocatorTypes.XPATH.value(), ".//body");
		WebElement we = webInteract.getElement(LocatorTypes.XPATH.value(),".//*[@id='div2']");
		
		//we.click();
		webInteract.hoverOnElement(we);
		//we.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		webInteract.getElement(LocatorTypes.XPATH.value(), ".//*[@id='treeview-1055-record-ext-record-9']/td[7]/div/div").click();
		webInteract.getElement(LocatorTypes.XPATH.value(), ".//*[@id='treeview-1055-record-ext-record-9']/td[7]/div/div").sendKeys("1");
		List<WebElement> projectMeetings = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("projectMeetings"));
		List<WebElement> systemtesting = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("systemTesting"));
		System.out.println(projectMeetings.size());
		for(int i = 1; i <= 5; i++)
		{
			projectMeetings.get(i).sendKeys("1");
			
		}
		
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("timesheetSaveButton")).click();
		
	}
}
