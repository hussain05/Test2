package com.mtv.pageObjects;

import java.util.List;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.mtv.constants.LocatorTypes;
import com.mtv.constants.Waits;
import com.mtv.interact.WebInteract;
import com.mtv.util.CommonMethods;
import com.mtv.util.ExplicitWaits;
import com.mtv.util.SoftAssertions;

public class RMPSearch1 {
	CommonMethods method = new CommonMethods();
	SoftAssertions sa;
	WebInteract webInteract;
	ExplicitWaits wait;

	public RMPSearch1(WebDriver driver) {
		webInteract = new WebInteract(driver);
		sa = new SoftAssertions();
		wait = new ExplicitWaits(driver);
	}

	public RMPSearch1(AndroidDriver driver) {
		webInteract = new WebInteract(driver);
		sa = new SoftAssertions();
		wait = new ExplicitWaits(driver);
	}

	public void verifyTypeAhead(String no, String term) {
		// System.out.println(term);
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("universalSearchField")).sendKeys(term);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("universalSearchDropdown"), Waits.LONGWAITSECONDS.value());
		List<WebElement> professorList = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("professorListTypeAhead"));
		List<WebElement> schoolList = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("schoolListTypeAhead"));
		for (WebElement we : professorList) {
			if (!we.getText().equals("")) { // System.out.println(we.getText());
				sa.assertTrue(we.getText().toLowerCase().contains(term), "Professor Term mismatch. Searched term " + term + " not found in Professor name " + we.getText());
			}
		}
		for (WebElement we : schoolList) {
			if (!we.getText().equals("")) {
				// System.out.println(we.getText());
				sa.assertTrue(we.getText().toLowerCase().contains(term), "School Term mismatch. Searched term " + term + " not found in School name " + we.getText());
			}
		}
		// System.out.println(no);
	}

	public void verifySearchResultsCount(String no, String term) {
		int count, professorCount, schoolCount;
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("universalSearchField")).sendKeys(term + Keys.ENTER);
		
		/************TOTAL COUNT CALC*************/
		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("resultsCount"), Waits.LONGWAITSECONDS.value());
		String s = webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("resultsCount")).getText();
		if (s.equalsIgnoreCase("Your search didn't return any results."))
			count = 0;
		else {
			int i = s.indexOf("of") + 3; // result count will be at 3rd index
											// from 'of'
			count = Integer.parseInt(s.substring(i).replaceAll("[^\\d]", ""));
		}
		
		/**************PROFESSOR COUNT CALC**********************/
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("professorFilterRadioButton")).click();
		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("resultsCount"), Waits.LONGWAITSECONDS.value());
		 s = webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("resultsCount")).getText();
		if (s.equalsIgnoreCase("Your search didn't return any results."))
			professorCount = 0;
		else {
			int i = s.indexOf("of") + 3; // result count will be at 3rd index
											// from 'of'
			professorCount = Integer.parseInt(s.substring(i).replaceAll("[^\\d]", ""));
		}
		
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("schoolFilterRadioButton")).click();
		
		/*****************SCHOOL COUNT CALC***************/
		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("resultsCount"), Waits.LONGWAITSECONDS.value());
		 s = webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("resultsCount")).getText();
		if (s.equalsIgnoreCase("Your search didn't return any results."))
			schoolCount = 0;
		else {
			int i = s.indexOf("of") + 3; // result count will be at 3rd index
											// from 'of'
			schoolCount = Integer.parseInt(s.substring(i).replaceAll("[^\\d]", ""));
		}
		
		Assert.assertEquals(count, schoolCount + professorCount);
		}
}
