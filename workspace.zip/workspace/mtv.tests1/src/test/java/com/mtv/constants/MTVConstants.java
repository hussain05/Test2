package com.mtv.constants;

public enum MTVConstants {
	
	TVSchedulePageUrl("http://www.mtv.com/tv-schedule"),
	TVSchedulePagePropFile("TVSchedulePage"),
	TVShowsUrl("http://www.mtv.com/shows"),
	TVShowsPropFile("TVShows"),
	ShowAreYouTheOneUrl("http://www.mtv.com/shows/catfish-the-tv-show"),
	ShowAreYouTheOnePagePropFile("AreYouTheOnePage"),
	SignInHeaderText("sign in to watch now"),
	SignInDescriptionText("Don't miss out! Get full access to this show and many others. Sign in now with your TV provider (it's included with your TV subscription)."),
	OptimumUsername("research37"),
	OptimumPassword("support37");
	
	private final String value;

	private MTVConstants(String value) {
		this.value = value;
	}

	public String value() {
		return value;
	}

}
