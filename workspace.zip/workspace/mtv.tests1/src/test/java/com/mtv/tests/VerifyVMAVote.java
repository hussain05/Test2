package com.mtv.tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mtv.common.Base;

import com.mtv.constants.VMAConstants;

import com.mtv.pageObjects.VMAVoteHome;
import com.mtv.util.CommonMethods;

public class VerifyVMAVote extends Base {
	VMAVoteHome VMAVoteHomePage;

	@BeforeClass
	public void init() {
		CommonMethods.setPropertyFileName(VMAConstants.VMAPropFileName.value());
		if (getDeviceType().equalsIgnoreCase("desktop")) {
			VMAVoteHomePage = new VMAVoteHome(getWebDriver());
		} else {
			VMAVoteHomePage = new VMAVoteHome(getAndroidDriver());
		}
		openUrl(VMAConstants.VMAUrl.value());
		VMAVoteHomePage.VMALogin();
	}

	@Test //(enabled=false)
	public void testVotingCategories() {
		VMAVoteHomePage.verifyVotingCategoriesExpansion();
	}

	@Test //(priority=1)
	public void testEmailLogin() {
		VMAVoteHomePage.verifyVMAEmailLogin();
	}

	@Test //(dependsOnMethods={"testEmailLogin"})
	public void testVote() {
		VMAVoteHomePage.verifyVote();
	}
}
