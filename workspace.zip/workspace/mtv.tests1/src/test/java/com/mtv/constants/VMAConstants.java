package com.mtv.constants;

public enum VMAConstants {
	
	VMAUrl("http://www.mtv.com/vma/vote/"),
	VMAPassword("f1c0d09253b3483d"),
	VMAPropFileName("VMAPage"),
	VMAVoteInvalidEmail("temp"),
	VMAVoteEmail("temp@temp.com");

	
	
	private final String value;

	private VMAConstants(String value) {
		this.value = value;
	}

	public String value() {
		return value;
	}
}
