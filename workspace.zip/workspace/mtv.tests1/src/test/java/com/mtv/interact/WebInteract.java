package com.mtv.interact;

import io.appium.java_client.android.AndroidDriver;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.mtv.common.Base;
import com.mtv.util.CommonMethods;

public class WebInteract {
	public WebDriver driverWeb;
	public AndroidDriver driverAndroid;
	CommonMethods method = new CommonMethods();

	public WebInteract(WebDriver driverWeb) {
		this.driverWeb = driverWeb;
	}

	public WebInteract(AndroidDriver driverAndroid) {
		this.driverAndroid = driverAndroid;
	}

	public boolean isElementPresentCheck(String locatorType, String locator) {
		try {
			getElement(locatorType, locator);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public boolean isElementsPresentCheck(String locatorType, String locator) {
		try {
			getElements(locatorType, locator);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public WebElement getElement(String locatorType, String locator) {
		if (Base.getDeviceType().equals("desktop"))
			return driverWeb.findElement(method.getBy(locatorType, locator));
		else
			return driverAndroid.findElement(method.getBy(locatorType, locator));
	}

	public List<WebElement> getElements(String locatorType, String locator) {
		if (Base.getDeviceType().equals("desktop"))
			return driverWeb.findElements(method.getBy(locatorType, locator));
		else
			return driverAndroid.findElements(method.getBy(locatorType, locator));
	}

	public void scrollDownToElement(String locatorType, String locator) {
		JavascriptExecutor jse;
		if (Base.getDeviceType().equalsIgnoreCase("desktop")) {
			while (!isElementPresentCheck(locatorType, locator)) {
				jse = (JavascriptExecutor) driverWeb;
				jse.executeScript("window.scrollBy(0,100)", "");
			}
		} else {
			while (!isElementPresentCheck(locatorType, locator)) {
				jse = (JavascriptExecutor) driverAndroid;
				jse.executeScript("window.scrollBy(0,100)", "");
			}
		}
	}

	public void scrollUpToElement(String locatorType, String locator) {
		JavascriptExecutor jse;
		if (Base.getDeviceType().equalsIgnoreCase("desktop")) {
			while (!isElementPresentCheck(locatorType, locator)) {
				jse = (JavascriptExecutor) driverWeb;
				jse.executeScript("window.scrollBy(0,-100)", "");
			}
		} else {
			while (!isElementPresentCheck(locatorType, locator)) {
				jse = (JavascriptExecutor) driverAndroid;
				jse.executeScript("window.scrollBy(0,-100)", "");
			}
		}
	}

	public void scrollDownToElement(WebElement webElement) {
		if (Base.getDeviceType().equalsIgnoreCase("desktop"))
			((JavascriptExecutor) driverWeb).executeScript("arguments[0].scrollIntoView(true);", webElement);
		else
			((JavascriptExecutor) driverAndroid).executeScript("arguments[0].scrollIntoView(true);", webElement);
	}

	public void hoverOnElement(String locatorType, String locator) {
		WebElement webElement = getElement(locatorType, locator);
		if (Base.getDeviceType().equalsIgnoreCase("desktop")) {
			Actions builder = new Actions(driverWeb);
			Action mouseOver = builder.moveToElement(webElement).build();
			mouseOver.perform();
		} else {
			Actions builder = new Actions(driverAndroid);
			Action mouseOver = builder.moveToElement(webElement).build();
			mouseOver.perform();
		}
	}
	public void hoverOnElement(WebElement we)
	{
	Actions builder = new Actions(driverWeb);   
	builder.moveToElement(we, 800, 280).click().build().perform();
	}
}
