package com.mtv.pageObjects;

import java.util.List;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.mtv.common.Base;
import com.mtv.constants.LocatorTypes;
import com.mtv.constants.RMPConstants;
import com.mtv.interact.WebInteract;
import com.mtv.util.CommonMethods;
import com.mtv.util.ExplicitWaits;
import com.mtv.util.SoftAssertions;

public class Ratings {

	WebDriver driverWeb;
	AndroidDriver driverAndroid;
	ExplicitWaits wait;
	CommonMethods method;
	WebInteract webInteract;
	SoftAssertions sa;

	public Ratings(WebDriver driver) {
		this.driverWeb = driver;
		wait = new ExplicitWaits(driver);
		webInteract = new WebInteract(driver);
	}

	public Ratings(AndroidDriver driver) {
		this.driverAndroid = driver;
		wait = new ExplicitWaits(driver);
		webInteract = new WebInteract(driver);
	}
	
	public void verifyRatingsOrder()
	{
		method  = new CommonMethods();
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("cookie")).click();
		verifyOrderByMostRated();
		Base.openUrl(RMPConstants.RatingsPageUrl.value());
		verifyOrderAlphabetical();
	}

	private void verifyOrderAlphabetical() {
		
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("sortDropdown")).click();
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("sortAlphabeticalOption")).click();
		
		//webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("departmentDropdown")).click();
		//webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("accounting")).click();
		
		Base.pause();
		
		while(webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("loadMore")).isDisplayed())
		{
			
			webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("loadMore")).click();
			Base.pause();
		}
		
		List<WebElement> professorList = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("professorList"));
		
		//System.out.println(professorList.size());
		
		String laterName;
		String formerName;
		
		formerName  = professorList.get(0).getText().replace("RATINGS", "").replaceAll("[0-9]","").replaceAll("\n",""); // OR \\d OR [0-9] & \n is for newline character
		int i = 0;
		
		for(WebElement we : professorList)
		{
			if(i == 0)
			{
				i++;
				continue;
				
			}
			laterName = we.getText().replace("RATINGS", "").replaceAll("[0-9]","").replaceAll("\n","");
			if(formerName.compareToIgnoreCase(laterName)>0)
			{
				System.out.println(formerName+" should be after "+laterName+" but is displayed vice versa");
			}
			
			formerName = laterName;
			
		}
		
	}

	private void verifyOrderByMostRated() {
		
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("sortDropdown")).click();
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("sortMostRatedOption")).click();
		
		//webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("departmentDropdown")).click();
		//webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("accounting")).click();
		
		Base.pause();
		
		while(webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("loadMore")).isDisplayed())
		{
			
			webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("loadMore")).click();
			Base.pause();
		}
		
		List<WebElement> professorList = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("professorList"));
		
		//System.out.println(professorList.size());
		
		int laterRatings;
		int formerRatings;
		
		formerRatings  = Integer.parseInt(professorList.get(0).getText().replaceAll("[^0-9]","")); // OR \\d OR [0-9]
		int i = 0;
		boolean b = true;
		for(WebElement we : professorList)
		{
			if(i == 0)
			{
				i++;
				continue;
				
			}
			laterRatings = Integer.parseInt(we.getText().replaceAll("[^0-9]",""));
			if(formerRatings<laterRatings)
			{
				System.out.println(formerRatings+" should be displayed after "+laterRatings+" but is displayed vice versa");
				b = false;
			}
			
			formerRatings = laterRatings;
			
		}
		if(b)
		{
			System.out.println("All ratings sorted properly");
		}
		
	}
}
