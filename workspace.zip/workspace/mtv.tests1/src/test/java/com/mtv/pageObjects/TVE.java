package com.mtv.pageObjects;

import java.awt.AWTException;
import java.util.ArrayList;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.mtv.common.Base;
import com.mtv.constants.LocatorTypes;
import com.mtv.constants.MTVConstants;
import com.mtv.constants.Waits;
import com.mtv.interact.WebInteract;
import com.mtv.util.CommonMethods;
import com.mtv.util.ExplicitWaits;
import com.mtv.util.SoftAssertions;

public class TVE {

	WebDriver driverWeb;
	AndroidDriver driverAndroid;
	ExplicitWaits wait;
	CommonMethods method;
	WebInteract webInteract;
	SoftAssertions sa;

	public TVE(WebDriver driver) {
		this.driverWeb = driver;
		wait = new ExplicitWaits(driver);
		webInteract = new WebInteract(driver);
		sa = new SoftAssertions();
		method = new CommonMethods();
	}

	public TVE(AndroidDriver driver) {
		this.driverAndroid = driver;
		wait = new ExplicitWaits(driver);
		webInteract = new WebInteract(driver);
		sa = new SoftAssertions();
		method = new CommonMethods();
	}

	public void openLockedEpisodes(){

		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("bala"),Waits.MEDIUMWAITSECONDS.value());
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("bala")).click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		WebElement we;
		String lockedIcon;
		String episodeName;
		for(int i = 1; i <= 4; i++)
		{
			System.out.println(i);
			Base.pause();
			Base.pause();

			we = webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("latestFullEpisodesTVE"+i));
			lockedIcon = we.getAttribute("class");
			we.click();
			Base.pause();
			Base.pause();
			episodeName = webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("episodeTitle")).getText();
			if(lockedIcon.contains("tve_locked"))
			{
				try
				{
					Assert.assertTrue(webInteract.isElementPresentCheck(LocatorTypes.XPATH.value(), method.getLocator("signInTVEButton")), "TVE Sign in module should be displayed for locked episode "+episodeName);

					verifySignIn();


				}
				catch(AssertionError e)
				{
					e.printStackTrace();
				} catch (AWTException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			else
			{
				try
				{ 
					Assert.assertFalse(webInteract.isElementPresentCheck(LocatorTypes.XPATH.value(), method.getLocator("signInTVEButton")), "TVE Sign in module should NOT be displayed for unlocked episode "+episodeName);
				}
				catch(AssertionError e)
				{

				}
			}
			Base.navigateBack();
		}

	}



	private void verifySignIn() throws AWTException {
		Base.pause();
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("signInTVEButton")).click();
		Base.pause();


		Actions act = new Actions(driverWeb);
		WebElement onElement = webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("optimumThumbnail"));

		act.keyDown(Keys.SHIFT).click(onElement).keyUp(Keys.SHIFT).build().perform();

		//webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("optimumThumbnail")).click();



		Base.pause();
		ArrayList<String> tabs = new ArrayList<String>(driverWeb.getWindowHandles());
		driverWeb.switchTo().window(tabs.get(1));
		Base.pause();
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("optimumUsername")).sendKeys(MTVConstants.OptimumUsername.value());
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("optimumPassword")).sendKeys(MTVConstants.OptimumPassword.value());

		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("optimumSignInButton")).click();
		Base.pause();
		//tabs = new ArrayList<String>( driverWeb.getWindowHandles());

		driverWeb.switchTo().window(tabs.get(0));

		//driverWeb.switchTo().defaultContent();


		//driverWeb.navigate().refresh();
		Base.pause();
		Base.pause();
		Base.pause();
		Base.pause();
		Base.pause();


		Actions builder = new Actions(driverWeb);
		WebElement we2 = webInteract.getElement(LocatorTypes.XPATH.value(), ".//*[@class='video_player pjs edge-player']");
		WebElement we3 = webInteract.getElement(LocatorTypes.XPATH.value(), ".//*[@class='video_player pjs edge-player']//.//div[5]/div[5]/div/div[2]/div[3]/div[1]");		 
		WebElement we4 = webInteract.getElement(LocatorTypes.XPATH.value(), ".//*[@class='video_player pjs edge-player']//.//div[5]/div[5]/div/div[2]/div[3]/div[2]");		

		Action mouseOver = builder.moveToElement(we2).moveToElement(we3).click().moveToElement(we4).click().build(); //Enter and exit fullscreen
		mouseOver.perform();	
		TVELogout();
	}

	private void TVELogout() {
		webInteract.getElement(LocatorTypes.XPATH.value(), ".//*[@id='t0_lc']/div/div/div[2]/img").click();
		Base.pause();
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("signOutButton")).click();
		Base.pause();

	}

}

