/***** Bug	RMPR-2199	
RMP QA- Typeahead returns professor list by matching school names instead***/
package com.mtv.tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.mtv.common.Base;
import com.mtv.constants.LocatorTypes;
import com.mtv.constants.RMPConstants;
import com.mtv.constants.Waits;
import com.mtv.interact.WebInteract;
import com.mtv.pageObjects.RMPSearch1;
import com.mtv.util.CommonMethods;
import com.mtv.util.DataProviderFunction;
import com.mtv.util.ExplicitWaits;

public class VerifyRMPSearch1 extends Base {

	DataProviderFunction dataProviderFunctionObject = new DataProviderFunction();
	CommonMethods method;
	RMPSearch1 RMPSearchObject;
	WebInteract webInteract;
	ExplicitWaits wait;
	

	@BeforeClass
	public void RMPinit() {
		 method = new CommonMethods();
		if(getDeviceType().equalsIgnoreCase("desktop"))
		{
			
			webInteract = new WebInteract(getWebDriver());
			RMPSearchObject = new RMPSearch1(getWebDriver());
			wait = new ExplicitWaits(getWebDriver());
		}
		
		else
		{
			
			webInteract = new WebInteract(getAndroidDriver());
			RMPSearchObject = new RMPSearch1(getAndroidDriver());
			wait = new ExplicitWaits(getAndroidDriver());
		}
		
		CommonMethods.setPropertyFileName(RMPConstants.SearchPropFileName.value());
		openUrl(RMPConstants.SearchURL.value());
		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("cookie"),Waits.LONGWAITSECONDS.value());
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("cookie")).click();
		
	}

	@Test(dataProvider = "DP1")
	public void RMPSearchTest(String no, String term) throws Exception {

		RMPSearchObject.verifySearchResultsCount(no, term);
		Thread.sleep(5000);
		openUrl(RMPConstants.SearchURL.value());
		Thread.sleep(5000);

	}

	@DataProvider(name = "DP1")
	public Object[][] createData1() {
		Object[][] retObjArr = dataProviderFunctionObject.getTableArray(
				"src\\test\\resources\\rmp_search_data.xls", "RMP_sheetname",
				"rmp_label");
		return (retObjArr);
	}

}
