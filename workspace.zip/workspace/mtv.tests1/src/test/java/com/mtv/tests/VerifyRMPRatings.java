package com.mtv.tests;

import org.testng.annotations.Test;

import com.mtv.common.Base;
import com.mtv.constants.RMPConstants;
import com.mtv.pageObjects.Ratings;
import com.mtv.util.CommonMethods;

public class VerifyRMPRatings extends Base {

	@Test
	public void testRatings() {

		Ratings RatingsObject;
		CommonMethods.setPropertyFileName(RMPConstants.RatingsPagePropFileName
				.value());

		if (getDeviceType().equalsIgnoreCase("desktop")) {
			RatingsObject = new Ratings(getWebDriver());
		}

		else {
			RatingsObject = new Ratings(getAndroidDriver());
		}
		
		openUrl(RMPConstants.RatingsPageUrl.value());
		RatingsObject.verifyRatingsOrder();

	}

}
