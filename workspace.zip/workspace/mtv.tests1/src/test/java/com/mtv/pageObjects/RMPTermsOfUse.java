package com.mtv.pageObjects;

import java.util.List;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.mtv.constants.LocatorTypes;
import com.mtv.interact.WebInteract;
import com.mtv.util.CommonMethods;
import com.mtv.util.ExplicitWaits;
import com.mtv.util.SoftAssertions;

public class RMPTermsOfUse {
	WebDriver driverWeb;
	AndroidDriver driverAndroid;
	ExplicitWaits wait;
	CommonMethods method;
	WebInteract webInteract;
	SoftAssertions sa;

	public RMPTermsOfUse(WebDriver driver) {
		this.driverWeb = driver;
		wait = new ExplicitWaits(driver);
		webInteract = new WebInteract(driver);
		method = new CommonMethods();
	}

	public RMPTermsOfUse(AndroidDriver driver) {
		this.driverAndroid = driver;
		wait = new ExplicitWaits(driver);
		webInteract = new WebInteract(driver);
		method = new CommonMethods();
	}

	public void checkLinks() {
		List<WebElement> links = webInteract.getElements(LocatorTypes.XPATH.value(), method.getLocator("hyperlinks"));
		for (WebElement we : links) {
			
			try
			{
			if(!we.getAttribute("href").contains("/app"))
			{
				Assert.assertFalse(we.getAttribute("href").contains("origin-relaunch.ratemyprofessors-q.mtvi.com"));
			}
			}
			catch(AssertionError e)
			{
				System.out.println("Link redirects out of domain for HREF = "+we.getAttribute("href")+ " for ");
				System.out.println(we.getText());
			}
		}
	}
}
