package com.mtv.tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.mtv.common.Base;
import com.mtv.constants.LocatorTypes;
import com.mtv.constants.RMPConstants;
import com.mtv.constants.Waits;
import com.mtv.interact.WebInteract;
import com.mtv.pageObjects.RMPLoginPage;
import com.mtv.util.CommonMethods;
import com.mtv.util.DataProviderFunction;
import com.mtv.util.ExplicitWaits;

public class VerifyRMPLogin extends Base {

	DataProviderFunction dataProviderFunctionObject = new DataProviderFunction();
	CommonMethods method;
	RMPLoginPage RMPloginObject;
	WebInteract webInteract;
	ExplicitWaits wait;
	

	@BeforeClass
	public void RMPinit() {
		 method = new CommonMethods();
		if(getDeviceType().equalsIgnoreCase("desktop"))
		{
			
			webInteract = new WebInteract(getWebDriver());
			RMPloginObject = new RMPLoginPage(getWebDriver());
			wait = new ExplicitWaits(getWebDriver());
		}
		
		else
		{
			
			webInteract = new WebInteract(getAndroidDriver());
			RMPloginObject = new RMPLoginPage(getAndroidDriver());
			wait = new ExplicitWaits(getAndroidDriver());
		}
		
		CommonMethods.setPropertyFileName(RMPConstants.LoginPagePropFileName.value());
		openUrl(RMPConstants.LoginPageURL.value());
		wait.explicitWaitForElement(LocatorTypes.XPATH.value(), method.getLocator("cookie"),Waits.LONGWAITSECONDS.value());
		webInteract.getElement(LocatorTypes.XPATH.value(), method.getLocator("cookie")).click();
		
	}

	@Test(dataProvider = "DP1")
	public void RMPLoginTest(String no, String result, String userName,
			String password) throws Exception {

		RMPloginObject.verifyLogin(no, result, userName, password);

	}

	@DataProvider(name = "DP1")
	public Object[][] createData1() {
		Object[][] retObjArr = dataProviderFunctionObject.getTableArray(
				"src\\test\\resources\\rmp_data.xls", "RMP_sheetname",
				"rmp_label");
		return (retObjArr);
	}

}
