package test;

public class Parent {
	public static int a = 10;
}
