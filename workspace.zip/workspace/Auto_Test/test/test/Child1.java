package test;

public class Child1 extends Parent {
	static Child2 c;
	public static void main(String arg[])
	{
		c = new Child2();
		c.main1();
		
		System.out.println("From child1 "+a);
	}
}
