package test;

public class Child2 extends Parent {
	public void main1()
	{
		a = 1000;
		System.out.println("From child2 "+a);
	}
}
