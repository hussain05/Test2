package script;

import java.util.Scanner;

public class Assignment2 {
static Scanner sc = new Scanner (System.in);
	public static void main(String arg[])
	{
		int a;
		System.out.println("Enter number");
		a = sc.nextInt();
		while(a>10||a<1)
		{
			System.out.println("Try Again by re-entering (Number should be in range 1-10)");
			a = sc.nextInt();
		}
		int i,j;
		for(i=1;i<=a;i++)
			{
			for(j=1;j<=i;j++)
			{
				System.out.print(j+"   ");
			}
			System.out.println();
			}
		
	}
}
