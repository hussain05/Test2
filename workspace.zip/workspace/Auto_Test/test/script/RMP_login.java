package script;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

public class RMP_login {
	private Selenium selenium;
	private WebDriver driver;
	private String baseUrl;
	@Before
	public void setUp() throws Exception {
//		WebDriver driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","test\\resources\\chromedriver.exe"); //for chrome
		//System.setProperty("webdriver.ie.driver","test\\resources\\IEDriverServer.exe"); //for IE
		driver = new ChromeDriver(); //for Chrome
		baseUrl = "http://origin-relaunch.ratemyprofessors-q.mtvi.com/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testRMP_login() throws Exception {
		selenium.open("");
		selenium.click("css=span.welcome");
		selenium.waitForPageToLoad("1200000");
		selenium.click("css=input.btn_login");
		selenium.waitForPageToLoad("1200000");
		assertTrue(selenium.isTextPresent("Either your username or password has been typed incorrectly"));
		selenium.type("id=email", "wqw@ww.com");
		selenium.click("css=input.btn_login");
		selenium.waitForPageToLoad("1200000");
		assertTrue(selenium.isTextPresent(""));
		selenium.type("id=email", "sas@FM.COM");
		selenium.type("id=password", "SFEFFDF");
		selenium.click("css=input.btn_login");
		selenium.waitForPageToLoad("1200000");
		assertTrue(selenium.isTextPresent(""));
		selenium.click("link=Sign up for an account");
		selenium.waitForPageToLoad("1200000");
		selenium.type("id=pFrName", "viacom");
		selenium.type("id=pLsName", "hussain");
		selenium.type("id=email", "viacom.hussain@gmail.com");
		selenium.type("id=confirm_email", "viacom.hussain@gmail.com");
		selenium.type("id=password", "123456");
		selenium.type("id=confirm_password", "123456");
		Thread.sleep(10000);
		//selenium.type("id=recaptcha_response_field", "352");
		selenium.click("id=create");
		assertTrue(selenium.getText("//form[@id='studentForm']/div[9]/span").equals("You must agree to the terms"));
		selenium.click("id=terms_conditions");
		selenium.click("id=create");
		selenium.waitForPageToLoad("1200000");
		assertTrue(selenium.isElementPresent("link=Login"));
		selenium.click("link=Login");
		selenium.waitForPageToLoad("1200000");
		selenium.type("id=email", "viacom.hussain@gmail.com");
		selenium.type("id=password", "123456");
		selenium.click("css=input.btn_login");
		selenium.waitForPageToLoad("1200000");
		assertTrue(selenium.isTextPresent(""));
	}

	@After
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
