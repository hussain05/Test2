package script;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.*;

import static org.testng.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

@SuppressWarnings("unused")
public class RMPFindProf {
	@SuppressWarnings("deprecation")
	private Selenium selenium;
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	@BeforeTest(alwaysRun = true)
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"test\\resources\\chromedriver.exe"); // for chrome
		// System.setProperty("webdriver.ie.driver","test\\resources\\IEDriverServer.exe");
		// //for IE
		driver = new ChromeDriver(); // for Chrome
		baseUrl = "http://origin-relaunch.ratemyprofessors-q.mtvi.com/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testRMPFindProf() throws Exception {
		selenium.open("http://www.ratemyprofessors.com/");
		// driver.get("http://www.ratemyprofessors.com/");
		driver.findElement(By.xpath(".//*[@id='findProfessorOption']/span"))
				.click();
		driver.findElement(By.xpath(".//*[@id='prof-name-btn']")).click();
		Assert.assertTrue(
				selenium.isElementPresent("xpath=.//*[@id='leftNav_error-message-align']"),
				"Professor field empty message displayed");
		// check whether validation message is displayed
		selenium.type("xpath=.//*[@id='searchProfessorName']", "re");
Thread.sleep(7000);
		/*Assert.assertTrue(
				selenium.isElementPresent("xpath=.//*[@id='profNameAc']/ul"),
				"Professor Dropdown displayed");*/
		
		Actions action = new Actions(driver);
		 Actions builder = new Actions(driver);
		 WebElement we3 = driver.findElement(By.xpath(".//*[@id='searchProfessorName']"));
		    action.moveToElement(we3).click().build().perform();
		    
		    WebElement we2=driver.findElement(By.xpath(".//*[@id='profNameAc']/ul"));
		    Action mouseOver = builder.moveToElement(we2).build();
		    mouseOver.perform();
		    
		    WebElement we1 = driver.findElement(By.xpath(".//*[@id='profNameAc']/ul/li[1]/span[1]"));
		    action.moveToElement(we1).click().build().perform();
		    
	//	String temp = driver.findElement(
		//		By.xpath(".//*[@id='profNameAc']/ul/li[1]/span[1]")).getText();
		//System.out.println(temp);
	//	selenium.click("xpath=.//*[@id='profNameAc']/ul/li[1]/span[1]");
		//selenium.isTextPresent(temp);
		

	}

	@AfterClass
	public void tearDown() {
		selenium.close();
		selenium.stop();
	}
}