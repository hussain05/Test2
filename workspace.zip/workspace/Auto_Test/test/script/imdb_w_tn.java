package script;

import com.google.common.base.Verify;
import com.thoughtworks.selenium.*;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

//import org.junit.AfterClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.server.SeleniumServer;
import org.testng.annotations.*;

import java.io.File;
import java.util.concurrent.TimeUnit;

import jxl.*;

@SuppressWarnings({ "deprecation", "unused" })
public class imdb_w_tn {
	private Selenium selenium;

	@BeforeTest
	public void setUp() throws Exception {
		WebDriver driver = new FirefoxDriver();
		String baseUrl = "https://www.imdb.com";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}
	@DataProvider(name="DP1") //position of this is fixed here
	public Object[][] createData()
	{
		Object[][] retobj = getTableArray("test\\resources\\data\\IMDB_data.xls","Sheet1", "label");
		return(retobj);
	}

	private String[][] getTableArray(String xlFilePath, String sheetName,
			String tableName) 
	{
		String[][] tabArray=null;
		try{
			Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));
			Sheet sheet = workbook.getSheet(sheetName);

			int startRow,startCol, endRow, endCol,ci,cj;

			Cell tableStart=sheet.findCell(tableName);
			startRow=tableStart.getRow();
			startCol=tableStart.getColumn();

			Cell tableEnd= sheet.findCell(tableName, startCol+1,startRow+1, 100, 64000,  false);                

			endRow=tableEnd.getRow();
			endCol=tableEnd.getColumn();

			System.out.println("startRow="+startRow+", endRow="+endRow+", " +
					"startCol="+startCol+", endCol="+endCol);
			tabArray=new String[endRow-startRow-1][endCol-startCol-1];
			ci=0;

			for (int i=startRow+1;i<endRow;i++,ci++){
				cj=0;
				for (int j=startCol+1;j<endCol;j++,cj++){
					tabArray[ci][cj]=sheet.getCell(j,i).getContents();
				}
			}
		}
		catch (Exception e)    {
			System.out.println("error in getTableArray()");

		}

		return(tabArray);
	}
	@Test (dataProvider = "DP1") 
	public void testImdb_w_tn(String Title, String Plot, String Director) throws Exception  {

		selenium.open("http://www.imdb.com/");
		selenium.type("id=navbar-query", Title);
		selenium.click("id=navbar-submit-button");
		//		for (int second = 0;; second++) {
		//			if (second >= 60) fail("timeout");
		//			try { if (selenium.isElementPresent("link="+Title)) break; } catch (Exception e) {}
		//			Thread.sleep(1000);
		//		}

		selenium.click("link="+Title);
		//		for (int second = 0;; second++) {
		//			if (second >= 60) fail("timeout");
		//			try { if (selenium.isElementPresent("xpath=/html/body[@id='styleguide-v2']/div[@id='wrapper']/div[@id='root']/div[@id='pagecontent']/div[@id='content-2-wide']/div[@id='maindetails_center_top']/div/div/table[@id='title-overview-widget-layout']/tbody/tr[1]/td[@id='overview-top']/div[6]/a[3]")) break; } catch (Exception e) {}
		//			Thread.sleep(1000);
		//		}

		Verify.verify(selenium.isTextPresent(Director));
		//verify movie plot is present in the movie details page
		Verify.verify(selenium.isTextPresent(Plot));
		//verify movie actor name is present in the movie details page


		//		selenium.open("");
		//		selenium.type("id=navbar-query", "the godfather");
		//		selenium.click("css=div.suggestionlabel");
		//		selenium.waitForPageToLoad("60000");
	}

	@AfterTest
	public void tearDown() throws Exception {
		selenium.stop();
	}




}
