package script;

import com.thoughtworks.selenium.SeleneseTestCase;
import com.thoughtworks.selenium.Selenium;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

@SuppressWarnings("deprecation")
public class anna_dean_wb extends SeleneseTestCase  {
	private Selenium selenium;
	String baseUrl;
	boolean b = false;
	@Override
	@Before
	public void setUp() throws Exception {
		//WebDriver driver = new FirefoxDriver();
		 System.setProperty("webdriver.chrome.driver","test\\resources\\chromedriver.exe"); //for chrome
			
			WebDriver driver = new ChromeDriver(); 
		baseUrl = "https://www.annauniv.edu/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
		//driver.manage().window().maximize();
	}

	@Test
	public void testAnna_dean_wb() throws Exception{
		selenium.open(baseUrl);
		selenium.mouseOver("id=link3");
		//selenium.mouseOver("id=menuItem4");
		selenium.click("id=menuItem4");
		selenium.waitForPageToLoad("60000");
		verifyEquals("Deans of Campuses", selenium.getText("//strong"));
		
		int i=0;
		for(i=2;i<5;i++)
		{
			if (selenium.getText("//tr["+i+"]/td/div/b").contains("Dr.A.Rajadurai"))
			{
				 
					 assertEquals("22232403", selenium.getText("//tr["+i+"]/td[3]/div"));
					 
			}
		}
		if (i==5)
			b=true;
		//System.out.println("assert does not abort");
		selenium.click("link=Mail");
	}

	@Override
	@After
	public void tearDown() throws Exception {
		if(b)
			System.out.println("Pass");
		else
			System.out.println("Fail");
		selenium.stop();
	}
}
