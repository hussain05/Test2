package script;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
anna_dean_wb.class,
wiki_rc.class})


public class TSJU {

}
