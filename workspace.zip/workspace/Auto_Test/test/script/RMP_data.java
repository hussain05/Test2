//Data Driven Test Framework using Selenium and TestNG
//This Test performs search for the movie and looks for the attributes on the result page
//Data is read from the Excel SS - movie_data.xls
package script;

import com.thoughtworks.selenium.*;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

//import org.junit.AfterClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import java.io.File;
import java.util.concurrent.TimeUnit;

import jxl.*; 

public class RMP_data extends SeleneseTestCase{
	private Selenium selenium;
	private WebDriver driver;
	private String baseUrl;
    @Override
	@BeforeTest
    public void setUp() throws Exception {
    	System.setProperty("webdriver.chrome.driver","test\\resources\\chromedriver.exe"); //for chrome
		//System.setProperty("webdriver.ie.driver","test\\resources\\IEDriverServer.exe"); //for IE
		driver = new ChromeDriver(); //for Chrome
		baseUrl = "http://origin-relaunch.ratemyprofessors-q.mtvi.com/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }
    
    
    @DataProvider(name = "DP1")
    public Object[][] createData1() {
        Object[][] retObjArr=getTableArray("test\\resources\\data\\rmp_data.xls",
                "RMP_sheetname", "rmp_label");
        return(retObjArr);
    }
    
	@Test (dataProvider = "DP1") 
	public void testDataProviderExample(String uName, 
            String pName) throws Exception {
		selenium.open("http://www.ratemyprofessors.com/");
		selenium.click("css=span.welcome");
		selenium.waitForPageToLoad("1200000");
		selenium.click("xpath=(.//*[@id='login']/span[2])");
		selenium.type("xpath=(.//*[@id='email']",uName);
		selenium.type("xpath=(.//*[@id='password']",pName);
		selenium.click("xpath=(.//*[@id='mainContent']/div[2]/form/div[4]/input");
		
		/*for (int second = 0;; second++) {
			if (second >= 60) fail("timeout");
			try { if (selenium.isElementPresent("link="+movieTitle)) break; } catch (Exception e) {}
			Thread.sleep(1000);
		}

		selenium.click("link="+movieTitle);
		for (int second = 0;; second++) {
			if (second >= 60) fail("timeout");
			try { if (selenium.isElementPresent("xpath=/html/body[@id='styleguide-v2']/div[@id='wrapper']/div[@id='root']/div[@id='pagecontent']/div[@id='content-2-wide']/div[@id='maindetails_center_top']/div/div/table[@id='title-overview-widget-layout']/tbody/tr[1]/td[@id='overview-top']/div[6]/a[3]")) break; } catch (Exception e) {}
			Thread.sleep(1000);
		}*/

		verifyTrue(selenium.isTextPresent("Either your username or password has been typed incorrectly"));
	}
    
    @Override
	@AfterClass
    public void tearDown(){
        selenium.close();
        selenium.stop();
    } 
    
    public String[][] getTableArray(String xlFilePath, String sheetName, String tableName){
        String[][] tabArray=null;
        try{
            Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));
            Sheet sheet = workbook.getSheet(sheetName);
            
            int startRow,startCol, endRow, endCol,ci,cj;
            
            Cell tableStart=sheet.findCell(tableName);
            startRow=tableStart.getRow();
            startCol=tableStart.getColumn();

            Cell tableEnd= sheet.findCell(tableName, startCol+1,startRow+1, 100, 64000,  false);                

            endRow=tableEnd.getRow();
            endCol=tableEnd.getColumn();
            
            System.out.println("startRow="+startRow+", endRow="+endRow+", " +
                    "startCol="+startCol+", endCol="+endCol);
            tabArray=new String[endRow-startRow-1][endCol-startCol-1];
            ci=0;

            for (int i=startRow+1;i<endRow;i++,ci++){
                cj=0;
                for (int j=startCol+1;j<endCol;j++,cj++){
                    tabArray[ci][cj]=sheet.getCell(j,i).getContents();
                }
            }
        }
        catch (Exception e)    {
            System.out.println("error in getTableArray()");
            
        }

        return(tabArray);
    }
   
}//end of class