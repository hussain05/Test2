//Data Driven Test Framework using Selenium and TestNG
//This Test performs search for the movie and looks for the attributes on the result page
//Data is read from the Excel SS - movie_data.xls
package script;

import com.thoughtworks.selenium.*;

//import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;

import java.io.File;
import java.util.concurrent.TimeUnit;

import jxl.*; 

public class jira_watchers extends SeleneseTestCase{

	WebDriver driver;
	String baseUrl;
	@Override
	@BeforeTest
	public void setUp() throws Exception {
		//System.setProperty("webdriver.chrome.driver","test\\resources\\chromedriver.exe"); 
		driver = new FirefoxDriver(); 
		baseUrl = "https://jira.mtvi.com";
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.get(baseUrl + "");
		driver.findElement(By.id("login-form-username")).clear();
		driver.findElement(By.id("login-form-username")).sendKeys("jivanih");
		driver.findElement(By.id("login-form-password")).clear();
		driver.findElement(By.id("login-form-password")).sendKeys("nuj@2016");
		Thread.sleep(5000);
		driver.findElement(By.id("login")).click();
	}


	@DataProvider(name = "DP1")
	public Object[][] createData1() {
		Object[][] retObjArr=getTableArray("test\\resources\\data\\ticket.xls",
				"Sheet1", "label");
		return(retObjArr);
	}

	@Test (dataProvider = "DP1") 
	public void testDataProviderExample(String ticket) throws Exception {
		
		Thread.sleep(5000);
		driver.get("https://jira.mtvi.com/browse/"+ticket);
		Thread.sleep(5000);
		driver.findElement(By.xpath(".//*[@id='footer-comment-button']")).click();
		
		driver.findElement(By.xpath(".//*[@id='comment']")).sendKeys("cc [~ramdasg]");
		driver.findElement(By.xpath(".//*[@id='issue-comment-add-submit']")).click();
	}

	@Override
	@AfterClass
	public void tearDown(){
		driver.quit();
	} 

	public String[][] getTableArray(String xlFilePath, String sheetName, String tableName){
		String[][] tabArray=null;
		try{
			Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));
			Sheet sheet = workbook.getSheet(sheetName);

			int startRow,startCol, endRow, endCol,ci,cj;

			Cell tableStart=sheet.findCell(tableName);
			startRow=tableStart.getRow();
			startCol=tableStart.getColumn();

			Cell tableEnd= sheet.findCell(tableName, startCol+1,startRow+1, 100, 64000,  false);                

			endRow=tableEnd.getRow();
			endCol=tableEnd.getColumn();

			System.out.println("startRow="+startRow+", endRow="+endRow+", " +
					"startCol="+startCol+", endCol="+endCol);
			tabArray=new String[endRow-startRow-1][endCol-startCol-1];
			ci=0;

			for (int i=startRow+1;i<endRow;i++,ci++){
				cj=0;
				for (int j=startCol+1;j<endCol;j++,cj++){
					tabArray[ci][cj]=sheet.getCell(j,i).getContents();
				}
			}
		}
		catch (Exception e)    {
			System.out.println("error in getTableArray()");

		}

		return(tabArray);
	}

}//end of class