//Junit 3 code with RC
package script;

import com.thoughtworks.selenium.*;
//import java.util.regex.Pattern;

@SuppressWarnings("deprecation")
public class wiki_rc extends SeleneseTestCase {
	@Override
	public void setUp() throws Exception {
		setUp("http://www.wikipedia.org/", "*firefox C://Program Files//Mozilla Firefox//firefox.exe"); 
	}
	public void testWiki() throws Exception {
		selenium.open("");
		selenium.click("css=strong");
		selenium.waitForPageToLoad("60000");
		selenium.type("id=searchInput", "selenium");
		selenium.click("id=searchButton");
		selenium.waitForPageToLoad("60000");
		assertEquals("Selenium - Wikipedia, the free encyclopedia", selenium.getTitle());
		verifyEquals("Selenium", selenium.getText("id=firstHeading"));
	}
}
