//Data Driven Test Framework using Selenium and TestNG
//This Test performs search for the movie and looks for the attributes on the result page
//Data is read from the Excel SS - movie_data.xls
package script;

import com.thoughtworks.selenium.*;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

//import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.File;
import java.util.concurrent.TimeUnit;

import jxl.*;
import org.testng.Reporter;

public class RMP_signup extends SeleneseTestCase {
	private Selenium selenium;
	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	int j;

	@Override
	@BeforeTest
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"test\\resources\\chromedriver.exe"); // for chrome
		// System.setProperty("webdriver.ie.driver","test\\resources\\IEDriverServer.exe");
		// //for IE
		driver = new ChromeDriver(); // for Chrome
		baseUrl = "http://origin-relaunch.ratemyprofessors-q.mtvi.com/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@DataProvider(name = "DP1")
	public Object[][] createData1() {
		Object[][] retObjArr = getTableArray(
				"test\\resources\\data\\rmp_signup.xls", "RMP_sheetname",
				"rmp_label");
		return (retObjArr);
	}

	@SuppressWarnings("deprecation")
	@Test(dataProvider = "DP1")
	public void testDataProviderExample(String i, String email, String c_email,
			String password, String c_password) throws Exception {
		selenium.open("http://www.ratemyprofessors.com/join.jsp");
		// selenium.click("css=span.welcome");
		// selenium.waitForPageToLoad("12000");
		// selenium.click("xpath=(.//*[@id='mainContent']/div[2]/form/div[4]/a[1])");
		selenium.type("id=email", email);
		selenium.type("id=confirm_email", c_email);
		selenium.click("id=password");
		selenium.type("id=password", password);
		selenium.click("id=confirm_password");
		selenium.type("id=confirm_password", c_password);
		selenium.waitForPageToLoad("10000");
		j = Integer.parseInt(i);
		if (j == 3) {
			driver.findElement(By.id("terms_conditions")).click();
			Thread.sleep(8000);
		}
		selenium.click("id=create");

		switch (j) {
		case 1:
			try {
				Assert.assertTrue(
						selenium.isElementPresent("xpath=.//*[@id='confirmEmail-required']"),
						"Confirm Email validation message display");
				Reporter.log("Confirm Email validation message display");
			} catch (AssertionError e) {
				// verificationErrors.append("FAIL");
				Reporter.log("FAIL- Confirm Email validation message failed to display");
				throw e;
			}
			try {
				Assert.assertTrue(
						selenium.isElementPresent("xpath=.//*[@id='studentForm']/div[3]/span"),
						"Email required message displayed");
				Reporter.log("Email required message displayed");
			} catch (AssertionError e) {
				// verificationErrors.append("FAIL");
				Reporter.log("FAIL- Email required message failed to display");
				throw e;
			}
			try {
				Assert.assertTrue(
						selenium.isElementPresent("xpath=.//*[@id='studentForm']/div[5]/span"),
						"Password validation message displayed");
				Reporter.log("Password validation message displayed");
			} catch (AssertionError e) {
				// verificationErrors.append("FAIL");
				Reporter.log("FAIL- Password validation message failed to display");
				throw e;
			}
			try {
				Assert.assertTrue(
						selenium.isElementPresent("xpath=.//*[@id='confirmpass-required']"),
						"Confirm password required message displayed");
				Reporter.log("Confirm password required message displayed");
			} catch (AssertionError e) {
				// verificationErrors.append("FAIL");
				Reporter.log("FAIL- Confirm password required message failed to display");
				throw e;
			}
			try {

				Assert.assertTrue(
						selenium.isElementPresent("xpath=.//*[@id='studentForm']/div[9]/span"),
						"Agree checkbox not checked message displayed");
				Reporter.log("Agree checkbox not checked message displayed");
			} catch (AssertionError e) {
				// verificationErrors.append("FAIL");
				Reporter.log("FAIL- Agree checkbox not checked message failed to display");
				throw e;
			}
			break;
		case 2:
			try {
				Assert.assertTrue(
						selenium.isElementPresent("xpath=.//*[@id='confirmEmail-lengthmatch']"),
						"Confirm Email does not match message display");
				Reporter.log("Confirm Email does not match message display");
			} catch (AssertionError e) {
				// verificationErrors.append("FAIL");
				Reporter.log("FAIL- Confirm Email does not match message failed to display");
				throw e;
			}
			try {

				Assert.assertTrue(
						selenium.isElementPresent("xpath=.//*[@id='confirmpass-lengthmatch']"),
						"Password does not match message displayed");
				Reporter.log("Password does not match message displayed");
			} catch (AssertionError e) {
				// verificationErrors.append("FAIL");
				Reporter.log("FAIL- Password does not match message failed to display");
				throw e;
			}
			break;
		case 3:
			Assert.assertTrue(selenium
					.isElementPresent("xpath=.//*[@id='mainContent']/div/p"),
					"Sign up complete");
			Reporter.log("Sign up complete");
			break;
		}
	}

	@Override
	@AfterClass
	public void tearDown() {
		selenium.close();
		selenium.stop();
	}

	public String[][] getTableArray(String xlFilePath, String sheetName,
			String tableName) {
		String[][] tabArray = null;
		try {
			Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));
			Sheet sheet = workbook.getSheet(sheetName);

			int startRow, startCol, endRow, endCol, ci, cj;

			Cell tableStart = sheet.findCell(tableName);
			startRow = tableStart.getRow();
			startCol = tableStart.getColumn();

			Cell tableEnd = sheet.findCell(tableName, startCol + 1,
					startRow + 1, 100, 64000, false);

			endRow = tableEnd.getRow();
			endCol = tableEnd.getColumn();

			System.out.println("startRow=" + startRow + ", endRow=" + endRow
					+ ", " + "startCol=" + startCol + ", endCol=" + endCol);
			tabArray = new String[endRow - startRow - 1][endCol - startCol - 1];
			ci = 0;

			for (int i = startRow + 1; i < endRow; i++, ci++) {
				cj = 0;
				for (int j = startCol + 1; j < endCol; j++, cj++) {
					tabArray[ci][cj] = sheet.getCell(j, i).getContents();
				}
			}
		} catch (Exception e) {
			System.out.println("error in getTableArray()");

		}

		return (tabArray);
	}

}// end of class