package script;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class bigtop_Chronological {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
int i=1;
int j=2;
int year1,year2,month1,month2;
String temp1, temp2;
  @Before
  public void setUp() throws Exception {
   // driver = new FirefoxDriver();
	  System.setProperty("webdriver.chrome.driver","test\\resources\\chromedriver.exe"); //for chrome
		//System.setProperty("webdriver.ie.driver","test\\resources\\IEDriverServer.exe"); //for IE
		driver = new ChromeDriver(); //for Chrome
    baseUrl = "http://www.mtv.com/fandom-awards/news";
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testAnnaDeanW() throws Exception {
    driver.get("http://www.mtv.com/fandom-awards/news");
    String[] s = new String[10];
    
    while(i<=4)
    {
    	s[i] = driver.findElement(By.xpath("//*[@id=\"t2_lc\"]/div/div/ul/li["+i+"]/a/div[2]/span[3]")).getText();
    	s[j] = driver.findElement(By.xpath("//*[@id=\"t2_lc\"]/div/div/ul/li["+j+"]/a/div[2]/span[3]")).getText();
    	temp1 = s[i].substring(6);
    	temp2 = s[j].substring(6);
    	year1 = Integer.parseInt(temp1);
    	year2 = Integer.parseInt(temp2);
    	temp1 = s[i].substring(3,4);
    	temp2 = s[j].substring(3,4);
    	month1 = Integer.parseInt(temp1);
    	month2 = Integer.parseInt(temp2);
    	if(month1<month2)
    		System.out.println("fail");
    	i++;
    	j++;
    }
    
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
