package script;

import java.io.File;
import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

public class MovieAwards_NomineesButton {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	@SuppressWarnings("deprecation")
	private Selenium selenium;

	@BeforeTest
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"test\\resources\\chromedriver.exe");
		driver = new ChromeDriver(); // for Chrome
		baseUrl = "http://mtvmovieawards-test.votenow.tv/test.php";
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testMovieAwards() throws Exception {
		driver.get("http://mtvmovieawards-test.votenow.tv/test.php");
		for (int i = 1; i <= 14; i++) {
			// driver.findElement(By.cssSelector("span.category-title")).click();
			((JavascriptExecutor) driver)
					.executeScript("window.scrollBy(0,50)");
			Thread.sleep(5000);
			if (i != 1)
				driver.findElement(
						By.xpath(".//*[@id='mtv-movie-awards']/div/div[1]/div/div["
								+ ((i * 2) - 1) + "]")).click();

			try {
				Assert.assertTrue(driver
						.findElement(
								By.xpath(".//*[@id='mtv-movie-awards']/div/div[1]/div/div["
										+ (i * 2)
										+ "]/div/div[1]/div[2]/div[1]/button"))
						.isDisplayed());

				Reporter.log("Button passed" + i + "\n");

				getscreenshot(i);
			} catch (AssertionError e) {
				// verificationErrors.append("FAIL");
				Reporter.log("Winner failed");
				throw e;
			}
			driver.findElement(
					By.xpath(".//*[@id='mtv-movie-awards']/div/div[1]/div/div["
							+ ((i * 2) - 1) + "]")).click();
		}

	}

	public void getscreenshot(int i) throws Exception {
		File scrFile = ((TakesScreenshot) driver)
				.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File("D:\\screenshot_Nominee_" + i
				+ ".png"));
		// The below method will save the screen shot in d drive with name
		// "screenshot.png"
		// FileUtils.copyFile(scrFile, new File("D:\\screenshot.png"));
	}

	@AfterTest
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
