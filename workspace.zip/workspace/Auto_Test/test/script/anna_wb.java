//Junit 4 code with webdriver backed
package script;

import com.thoughtworks.selenium.Selenium;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class anna_wb {
	private Selenium selenium;

	@Before
	public void setUp() throws Exception {
		//WebDriver driver = new FirefoxDriver();
System.setProperty("webdriver.chrome.driver","test\\resources\\chromedriver.exe"); //for chrome
		
		WebDriver driver = new ChromeDriver(); 
		String baseUrl = "https://www.annauniv.edu/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}

	@Test
	public void testAnna_wb() throws Exception {
		selenium.open("");
		selenium.click("link=Departments");
		selenium.waitForPageToLoad("60000");
		selenium.mouseOver("css=#link3 > strong");
		selenium.mouseOver("id=menuItemHilite33");
		selenium.click("id=menuItemHilite33");
		selenium.waitForPageToLoad("60000");
	}

	@After
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
