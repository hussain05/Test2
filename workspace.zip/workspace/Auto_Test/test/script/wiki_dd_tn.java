//TEstNGcode with webdriver backed
package script;

import com.thoughtworks.selenium.SeleneseTestCase;
import com.thoughtworks.selenium.Selenium;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

import java.io.File;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

public class wiki_dd_tn extends SeleneseTestCase{
	private Selenium selenium;

	@Override
	@BeforeTest
	public void setUp() throws Exception {
		WebDriver driver = new FirefoxDriver(); //to run on FF; can use other browser drivers
		String baseUrl = "https://www.wikipedia.org/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}

	 @DataProvider(name = "DP1")
	    public Object[][] createData1() {
	        Object[][] retObjArr=getTableArray("test\\resources\\data\\wiki_data.xls",
	                "DataPool", "label");
	        return(retObjArr);
	    }
	    
		@Test (dataProvider = "DP1") 
		public void wiki_dd_tn1(String search) throws Exception {
			selenium.open("https://www.wikipedia.org/");
			selenium.click("css=strong");
			selenium.waitForPageToLoad("60000");
			selenium.type("id=searchInput", search);
			selenium.click("id=searchButton");
			
			//assertEquals("Selenium - Wikipedia, the free encyclopedia", selenium.getTitle());
		
//			for (int second = 0;; second++) {
//				if (second >= 60) fail("timeout");
//				try { if (selenium.isElementPresent("link="+movieTitle)) break; } catch (Exception e) {}
//				Thread.sleep(1000);
//			}

//			selenium.click("link="+movieTitle);
//			for (int second = 0;; second++) {
//				if (second >= 60) fail("timeout");
//				try { if (selenium.isElementPresent("xpath=/html/body[@id='styleguide-v2']/div[@id='wrapper']/div[@id='root']/div[@id='pagecontent']/div[@id='content-2-wide']/div[@id='maindetails_center_top']/div/div/table[@id='title-overview-widget-layout']/tbody/tr[1]/td[@id='overview-top']/div[6]/a[3]")) break; } catch (Exception e) {}
//				Thread.sleep(1000);
//			}

	        verifyTrue(selenium.isTextPresent(search));
	        
		}
	    
	    
	    
	    public String[][] getTableArray(String xlFilePath, String sheetName, String tableName){
	        String[][] tabArray=null;
	        try{
	            Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));
	            Sheet sheet = workbook.getSheet(sheetName);
	            
	            int startRow,startCol, endRow, endCol,ci,cj;
	            
	            Cell tableStart=sheet.findCell(tableName);
	            startRow=tableStart.getRow();
	            startCol=tableStart.getColumn();

	            Cell tableEnd= sheet.findCell(tableName, startCol+1,startRow+1, 100, 64000,  false);                

	            endRow=tableEnd.getRow();
	            endCol=tableEnd.getColumn();
	            
	            System.out.println("startRow="+startRow+", endRow="+endRow+", " +
	                    "startCol="+startCol+", endCol="+endCol);
	            tabArray=new String[endRow-startRow-1][endCol-startCol-1];
	            ci=0;

	            for (int i=startRow+1;i<endRow;i++,ci++){
	                cj=0;
	                for (int j=startCol+1;j<endCol;j++,cj++){
	                    tabArray[ci][cj]=sheet.getCell(j,i).getContents();
	                }
	            }
	        }
	        catch (Exception e)    {
	            System.out.println("error in getTableArray()");
	            
	        }

	        return(tabArray);
	    }
	   

	@Override
	@AfterTest
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
