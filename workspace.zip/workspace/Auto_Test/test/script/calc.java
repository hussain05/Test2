//Junit 4 code with webdriver backed
package script;

import com.thoughtworks.selenium.Selenium;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class calc {
	private Selenium selenium;
	WebDriver driver;

	@Before
	public void setUp() throws Exception {
		//WebDriver driver = new FirefoxDriver(); //to run on FF; can use other browser drivers
		//****************PLEASE CHANGE TEST to CP-SAT_Hussain below****************************
	System.setProperty("webdriver.chrome.driver","test\\resources\\chromedriver.exe"); //for chrome
		//System.setProperty("webdriver.ie.driver","test\\resources\\IEDriverServer.exe"); //for IE
		 driver = new ChromeDriver(); //for Chrome
		//WebDriver driver1 = new InternetExplorerDriver(); //for IE
		String baseUrl = "https://www.wikipedia.org/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);  //For RC commands below; better remove if using PURE webdriver code
	}

	@Test
	public void testWiki_wb() throws Exception {
		driver.navigate().to("http://www.calculator.net/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath(".//*[@id='menu']/div[3]/a")).click();
		driver.findElement(By.xpath(".//*[@id='menu']/div[4]/div[3]/a")).click();
		driver.findElement(By.id("cpar1")).sendKeys("10");
		Thread.sleep(3000);

	}

	@After
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
