package script;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class webdriver_anna1 {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	@BeforeTest
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		baseUrl = "https://www.annauniv.edu/";
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	@Test
	public void testWebdriverAnna1() throws Exception {
		driver.get(baseUrl + "");
		driver.findElement(By.linkText("Departments")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [mouseOver |
		// css=#link3 > strong | ]]
		// ERROR: Caught exception [ERROR: Unsupported command [mouseOver |
		// id=menuItemHilite33 | ]]
		driver.findElement(By.linkText("Mail")).click();
//		try {
//			assertEquals(
//					driver.findElement(
//							By.xpath("//table/tbody/tr[3]/td/table/tbody/tr[1]/td[1]/table[1]/tbody/tr[3]/td[2]"))
//							.getText(),
//					"Never share your password and do not respond to any mail which asks for Login-ID/Password.");
//		} catch (Error e) {
//			verificationErrors.append(e.toString());
//		}
		try {
			//assertTrue(isElementPresent(By.cssSelector("td.style9 > img")));
			Assert.assertTrue(isElementPresent(By.xpath("//tr[3]/td/img")));
			Thread.sleep(3000);
			System.out.println("Element verified");
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	@AfterTest
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			Assert.fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
