package script;

import com.thoughtworks.selenium.Selenium;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

@SuppressWarnings("deprecation")
public class landmark_wb {
	private Selenium selenium;
	WebDriver driver;

	@Before
	public void setUp() throws Exception {
		//WebDriver driver = new FirefoxDriver();
		 System.setProperty("webdriver.chrome.driver","test\\resources\\chromedriver.exe"); //for chrome
			
			driver = new ChromeDriver(); //for Chrome
		String baseUrl = "https://www.annauniv.edu/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
		//selenium.windowMaximize();
		//selenium.windowFocus();
	//	selenium.setTimeout("90000");
		driver.manage().window().maximize();
	}

	@Test
	public void testLandmark_wb() throws Exception 
	{
		selenium.open("http://www.landmarkonthenet.com/");
		selenium.select("id=TopSearch-categories", "label=Books");
		selenium.click("id=TopSearch");
		selenium.type("id=TopSearch", "junit");
		selenium.click("css=button[type=\"submit\"]");
		selenium.waitForPageToLoad("60000"); //precedence over setTimeOut declared in before block
		selenium.click("xpath=(//a[contains(text(),'Asc')])[2]");
		selenium.waitForPageToLoad("60000");
		//compare code starts here
		for (int i=1; i<20; i++)
		{
			String a = selenium.getText("//div[@id='page-content']/div[3]/div["+i+"]//span[@class='pricelabel']");
			String b = selenium.getText("//div[@id='page-content']/div[3]/div["+(i+1)+"]//span[@class='pricelabel']");
					
			//div[@id='page-content']/div[3]/div[3]/article/div[2]/p/span
			//selenium.getEval("var A=Number(\"" + a + "\".substring(3).replace(/,/g,'')); var B=Number(\"" + b + "\".substring(3).replace(/,/g,'')); if(A<B) alert ('Pass')");
			int A = Integer.parseInt(a.substring(3).replaceAll("[-+.^:,]",""));
			int B = Integer.parseInt(b.substring(3).replaceAll("[-+.^:,]",""));
			System.out.println("A "+A);
			System.out.println("B "+B);
			
			if (A<B)
			{
				System.out.println("Pass for Item no. " +i+" and "+(i+1));
			}
				
			else
			{
				System.out.println("Fail for Item no. " +i+" and "+(i+1));
			}
		}
		
	}

	@After
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
