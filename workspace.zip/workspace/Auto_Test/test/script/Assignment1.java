package script;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Assignment1 {

	static Scanner sc = new Scanner(System.in);

	public static void main(String arg[]) {

		Double num1 = (double) 0;
		Double num2 = (double) 0;
		char operator;
		try {
			System.out.println("Enter number 1");
			num1 = sc.nextDouble();
			System.out.println("Enter number 2");
			num2 = sc.nextDouble();

			System.out.println("Enter operator [ + , - , % , * ]");
			operator = sc.next().charAt(0);
			System.out.println(operator);
			switch (operator) {
			case '+':
				System.out.println("You chose Addition operation. Value of "
						+ num1 + " + " + num2 + " = " + (num1 + num2));
				break;
			case '-':
				System.out.println("You chose Subtraction operation. Value of "
						+ num1 + " - " + num2 + " = " + (num1 - num2));
				break;
			case '%': {
				try {
					if (num2 == 0)
						throw new ArithmeticException();
					else

						System.out.println("You chose Mod operation. Value of "
								+ num1 + " % " + num2 + " = " + (num1 % num2));
				} catch (ArithmeticException ee) {
					System.out.println("Exception thrown because num2 is 0 :"
							+ ee);
				}

				break;
			}
			case '*':
				System.out
						.println("You chose Multiplication operation. Value of "
								+ num1 + " * " + num2 + " = " + (num1 * num2));
				break;
			default: {
				System.out.println("You chose an invalid operation");
				break;

			}
			}
		} catch (InputMismatchException e) {
			System.out
					.println("Exception thrown as input entered is not a number "
							+ e);
		}
	}

}
