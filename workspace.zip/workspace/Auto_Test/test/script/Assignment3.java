package script;

import java.util.Scanner;

public class Assignment3 {
static Scanner sc = new Scanner (System.in);
	public static void main(String arg[])
	{
		String s="";
		String reverse = "";
System.out.println("Enter any string");
s=sc.nextLine();
char a;
//a=s.toCharArray();
int i;
for(i=s.length()-1;i>=0;i--)
{
	a = s.charAt(i);
	reverse += a;
	
	//System.out.println(i);
}
	System.out.println(reverse);

	}
}
