package script;


import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class anna_w {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
   // driver = new FirefoxDriver();
	  System.setProperty("webdriver.chrome.driver","test\\resources\\chromedriver.exe"); //for chrome
		
		 driver = new ChromeDriver(); 
    baseUrl = "https://www.annauniv.edu/";
   driver.manage().window().maximize();
  //  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testAnnaDeanW() throws Exception {
    driver.get(baseUrl + "");
    // ERROR: Caught exception [ERROR: Unsupported command [mouseOver | id=link3 | ]]
    // ERROR: Caught exception [ERROR: Unsupported command [mouseOver | id=menuItemHilite4 | ]]
    //driver.findElement(By.id("link3")).click();
    Actions action = new Actions(driver);
    
//    WebElement we = driver.findElement(By.id("link3"));
//    action.moveToElement(we).build().perform();

    Thread.sleep(10000);
    driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td/table/tbody/tr/td/table[2]/tbody/tr[2]/td[1]/div/b")).click();
    
    Actions builder = new Actions(driver);
    
    //first mouseOver
    WebElement we=driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td/table/tbody/tr/td/table[2]/tbody/tr[2]/td[1]/div/b"));
    Action mouseOver = builder.moveToElement(we).build();
    mouseOver.perform();
    
    //second mouseOver
    we = driver.findElement(By.id("menuItemHilite26"));
    mouseOver = builder.moveToElement(we).build();
    mouseOver.perform();
    
    //third mouseOver
    we = driver.findElement(By.id("menuItemHilite33"));
    mouseOver = builder.moveToElement(we).build();
    mouseOver.perform();
    
    //driver.findElement(By.id("menuItemHilite4")).click();
    try {
      assertEquals("Deans of Campuses", driver.findElement(By.xpath("//strong")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertEquals("Dr. P.Narayanasamy", driver.findElement(By.xpath("//tr[2]/td/div/b")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertEquals("22301357", driver.findElement(By.xpath("//tr[2]/td[3]/div")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.linkText("Mail")).click();
    Thread.sleep(5000);
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
