package script;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.net.URL;

import com.thoughtworks.selenium.Selenium;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

@SuppressWarnings("deprecation")
public class GRID_Sample {
	private Selenium selenium;
	WebDriver driver;
	DesiredCapabilities capability;
	String baseUrl;

	@Before
	public void setUp() throws Exception {

		/*File file = new File(
				"C:\\Users\\10611983\\Google Drive\\Selenium_workspace\\Advanced_sel_Hussain\\src\\resources\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());*/
		 //driver = new FirefoxDriver();//chromedriver path of node
		// System.setProperty("webdriver.chrome.driver","test\\resources\\chromedriver.exe");
		// //for chrome
		capability = DesiredCapabilities.firefox();
		//capability.setBrowserName("firefox");
	    capability.setPlatform(Platform.MAC);
		driver = new RemoteWebDriver(new URL(
				"http://172.21.255.106:5555/wd/hub/"), capability); //IP of node
		baseUrl = "https://www.annauniv.edu/";

		driver.manage().window().maximize();
	}

	@Test
	public void GRID() throws Exception {
		driver.get(baseUrl);

		driver.findElement(By.linkText("Mail")).click();
		Thread.sleep(5000);
	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

}
