package script;

import junit.framework.Assert;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Cucumber_stepsFile {

	
	int num1, num2, result;
	String option;
	Add_class object1 = new Add_class();
@Given("^the input numbers (\\d+) and (\\d+)$")
public void the_input_numbers_and(int arg1, int arg2) throws Throwable {
    num1 = arg1;
    num2 = arg2;
    //throw new PendingException();
}

@When("^\"([^\"]*)\" is selected as option$")
public void is_selected_as_option(String arg1) throws Throwable {
    option = arg1;
   // throw new PendingException();
}

@Then("^output should be (\\d+)$")
public void output_should_be(int arg1) throws Throwable {
    
	result = object1.Add_func(num1, num2);
	Assert.assertEquals(result, arg1);
	
    //throw new PendingException();
}

}
