package script;

import org.junit.runner.RunWith;

import cucumber.api.*;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(tags="@positive", features="test/resources/", monochrome = true) //Run all features with tag positive
//@CucumberOptions(tags="@positive", features="test/resources/Calc_features.feature", monochrome = true) //Run features with tag positive inside Calc_features file
//@CucumberOptions(tags={"@positive","@negative"}, features="test/resources/Calc_features.feature", monochrome = true) //Run scenarios with tags positive AND negative
//@CucumberOptions(tags={"@positive,@negative"}, features="test/resources/Calc_features.feature", monochrome = true) //Run scenarios with tags positive OR negative
public class Cucumber_testRunner {

	
}
