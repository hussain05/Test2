package script;

public class Add_class {
	int Add_func(int a, int b) {
		return a + b;
	}
}