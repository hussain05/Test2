package com.mtv.tests;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.mtv.common.Base;
import com.mtv.constants.LocatorTypes;

public class RMPTests extends Base {
	

	@BeforeTest
	@Parameters("Browser")
	public void setUp(String browser)
	{
		System.out.println("1:"+browser);
		setBrowserType(browser);
		//System.out.println("1g"+getBrowserType());
		Base1();
	
	}
	

	@Test
	
	public void test1 () {
		/*System.out.println("1:"+browser);
		setBrowserType(browser);
		//System.out.println("1g"+getBrowserType());
		Base1();
	

		*/
		openUrl("http://www.ratemyprofessors.com");
		Assert.assertEquals(getCurrentUrl(), "http://www.ratemyprofessors.com/");
		ew.explicitWaitForElement(".//*[@id='cookie_notice']/a[1]", 5000);
		wi.getElement(LocatorTypes.XPATH.value(), ".//*[@id='cookie_notice']/a[1]").click();
	}

	@Test
	
	
	public void test2 () {
		/*System.out.println("2:"+browser);
		setBrowserType(browser);
		
		Base1();*/
		openUrl("http://www.google.com");
		ew.explicitWaitForElement(".//*[@id='hplogo']", 5000);
		wi.isElementPresentCheck(LocatorTypes.XPATH.value(), ".//*[@id='hplogo']");
		wi.getElement(LocatorTypes.XPATH.value(), ".//*[@id='hplogo']").click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@AfterMethod
	public void afterMethod() {
		close();
	}
}
