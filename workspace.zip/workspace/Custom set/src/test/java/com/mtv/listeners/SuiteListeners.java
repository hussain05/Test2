package com.mtv.listeners;

import org.testng.ISuite;
import org.testng.ISuiteListener;

import com.mtv.common.Base;



public class SuiteListeners extends Base implements ISuiteListener {
	@Override
	public void onStart(ISuite suite) {
		if (suite.getParameter("Device").equalsIgnoreCase("desktop")) {
			setDeviceType("desktop");
		} else {
			setDeviceType("mobile");
		}
	}

	@Override
	public void onFinish(ISuite suite) {
		System.out.println("================= Finished ================");
		
	}
}