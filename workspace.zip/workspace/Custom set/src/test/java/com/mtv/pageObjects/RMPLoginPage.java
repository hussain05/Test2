package com.mtv.pageObjects;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.WebDriver;
import com.mtv.common.Base;
import com.mtv.constants.LocatorTypes;
import com.mtv.interact.WebInteract;
import com.mtv.util.CommonMethods;
import com.mtv.util.SoftAssertions;

public class RMPLoginPage {
	
}
