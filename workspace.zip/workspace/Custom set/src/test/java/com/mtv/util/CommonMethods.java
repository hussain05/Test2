package com.mtv.util;

import java.util.Properties;

import org.openqa.selenium.By;

import com.mtv.common.Base;
import com.mtv.constants.LocatorTypes;

public class CommonMethods extends Base {
	Properties prop;
	static public String propertyFileName;

	public static void setPropertyFileName(String PropertyFileName) {
		propertyFileName = PropertyFileName;
	}

	public String getPropertyFileName() {
		return propertyFileName;
	}

	public String getLocator(String locatorName) {
		prop = ReadProperties.readPropertyFile(getPropertyFileName(), getDeviceType());
		return prop.getProperty(locatorName);
	}

	public By getBy(String locatorType, String locator) {
		if (locatorType.equals(LocatorTypes.XPATH.value()))
			return By.xpath(locator);
		else if (locatorType.equals(LocatorTypes.ID.value()))
			return By.id(locator);
		else if (locatorType.equals(LocatorTypes.CSS.value()))
			return By.cssSelector(locator);
		else if (locatorType.equals(LocatorTypes.TAGNAME.value()))
			return By.tagName(locator);
		else
			return By.className(locator);
	}
}
