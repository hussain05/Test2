package com.mtv.constants;

	
	public enum DeviceTypes {
		
		Desktop("desktop"),
		Mobile("mobile");
		
		private final String value;

		private DeviceTypes(String value) {
			this.value = value;
		}

		public String value() {
			return value;
		}

	}


