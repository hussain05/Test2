package com.mtv.util;

import org.testng.asserts.Assertion;
import org.testng.asserts.IAssert;

public class SoftAssertions extends Assertion {
	@Override
	public void executeAssert(IAssert a) {
		try {
			a.doAssert();
		} catch (AssertionError ex) {
			System.out.println(a.getMessage());
		}
	}
}
