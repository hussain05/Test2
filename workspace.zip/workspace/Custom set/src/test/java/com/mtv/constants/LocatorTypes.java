package com.mtv.constants;

public enum LocatorTypes {
	
	XPATH("xpath"),
	CSS("css"),
	ID("id"),
	CLASS("class"),
	TAGNAME("tag");
	
	private final String value;

	private LocatorTypes(String value) {
		this.value = value;
	}

	public String value() {
		return value;
	}

}
