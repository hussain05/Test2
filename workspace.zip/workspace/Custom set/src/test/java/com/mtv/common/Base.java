package com.mtv.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.mtv.constants.BrowserTypes;
import com.mtv.constants.DeviceTypes;
import com.mtv.interact.WebInteract;
import com.mtv.util.CommonMethods;
import com.mtv.util.ExplicitWaits;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

@SuppressWarnings("unused")
public class Base {
	
	public WebDriver driver;
	public static String DeviceType;
	public String BrowserType;
	DriverFactory df = new DriverFactory();
	protected WebInteract wi;
	protected ExplicitWaits ew;
	protected CommonMethods cm;
	
	 public void Base1()
	 {System.out.println("2g"+BrowserType);
		 df.setWebDriver(BrowserType);
		 driver = df.getWebDriver();
		 wi = new WebInteract(driver);
		 ew = new ExplicitWaits(driver);
		 cm = new CommonMethods();
	 }
	 
	 public void openUrl(String url)
	 {
		 driver.get(url);
		 driver.manage().window().maximize();
	 }
	 
	 public String getCurrentUrl()
	 {
		 return driver.getCurrentUrl();
	 }
	 public static void setDeviceType(String DeviceType1)
	 {
		 DeviceType = DeviceType1;
	 }
	 public static String getDeviceType()
	 {
		 return DeviceType;
	 }
	 public void close()
	 {
		 driver.close();
		 
	 }
	 public  void setBrowserType(String BrowserType1)
	 {
		 BrowserType = BrowserType1;
	 }
	 
	 public String getBrowserType()
	 {
		 return BrowserType;
	 }
	 
}
