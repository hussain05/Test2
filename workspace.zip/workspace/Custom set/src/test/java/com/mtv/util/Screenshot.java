package com.mtv.util;

import java.io.File;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot {
	WebDriver driver;

	public Screenshot(WebDriver driver) {
		this.driver = driver;
	}

	@SuppressWarnings("deprecation")
	public void getscreenshot(String fileName) throws Exception {
		Date d = new Date();
		File scrFile = ((TakesScreenshot) driver)
				.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File("D:\\New\\" + fileName + " " +d.getHours() + "  "+ d.getMinutes() + ".png"));

	}
}