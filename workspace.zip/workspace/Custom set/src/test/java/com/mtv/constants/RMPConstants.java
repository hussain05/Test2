package com.mtv.constants;

public enum RMPConstants {
	
	LoginPageURL("http://www.ratemyprofessors.com/member"),
	LoginPagePropFileName("RMPLoginPage"),
	
	RatingsPageUrl("http://www.ratemyprofessors.com/campusRatings.jsp?sid=939"),
	RatingsPagePropFileName("RMPRatingsPage"),
	
	TermsOfUseURL("http://origin-relaunch.ratemyprofessors-q.mtvi.com/app/TermsOfUse_us.jsp#guidelines"),
	TermsOfUsePropFileName("RMPTermsOfUse"),
	
	SearchURL("http://www.ratemyprofessors.com"),
	SearchPropFileName("RMPSearch");
	
	private final String value;

	private RMPConstants(String value) {
		this.value = value;
	}

	public String value() {
		return value;
	}

}
