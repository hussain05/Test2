package com.mtv.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.mtv.constants.BrowserTypes;


public class DriverFactory {
	public WebDriver driver;
	
	

	public void setWebDriver(String BrowserType) {
		System.out.println("DF:"+BrowserType);
		if("Chrome".equals(BrowserType))
		{
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-extensions");
			driver = new ChromeDriver(options);
		}
		
		else if("Firefox".equals(BrowserType))
		{
			driver = new FirefoxDriver();
		}
		
		else
		{
			driver = new InternetExplorerDriver();
		}
		
	}

	public WebDriver getWebDriver() {
		return driver;
	}

	
	
}
