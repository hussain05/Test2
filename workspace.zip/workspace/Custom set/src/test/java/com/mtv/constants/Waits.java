package com.mtv.constants;

public enum Waits {

	SHORTWAITSECONDS(5), 
	MEDIUMWAITSECONDS(10), 
	LONGWAITSECONDS(20);

	private final int value;

	private Waits(int value) {
		this.value = value;
	}

	public int value() {
		return value;
	}

}
