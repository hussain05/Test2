package com.mtv.constants;

public enum BrowserTypes {
	
	Chrome("chrome"),
	Firefox("firefox"),
	IE("ie");
	
	private final String value;

	private BrowserTypes(String value) {
		this.value = value;
	}

	public String value() {
		return value;
	}

	
}
