package com.mtv.util;

import org.openqa.selenium.remote.DesiredCapabilities;

public class SetCapabilities {

	public DesiredCapabilities capabilities;

	public DesiredCapabilities SetCapabilitiesAndroid() {
		capabilities = new DesiredCapabilities();
		capabilities.setCapability("browserName", "Chrome");
		capabilities.setCapability("deviceName", "Samsung");
		capabilities.setCapability("automationName", "Appium");
		capabilities.setCapability("udid", "1215fc6d0a8e3a04"); //ofc S6- 1215fc6d0a8e3a04, Home S5- 50681106
		capabilities.setCapability("platformVersion", "6.0");
		capabilities.setCapability("platformName", "Android");
		
		return capabilities;
	}
}
