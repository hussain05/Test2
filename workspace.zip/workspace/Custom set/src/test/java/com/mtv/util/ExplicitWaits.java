package com.mtv.util;

import org.openqa.selenium.WebDriver;
import com.mtv.interact.WebInteract;


import io.appium.java_client.android.AndroidDriver;

public class ExplicitWaits extends WebInteract {

	public ExplicitWaits(AndroidDriver driverAndroid) {
		super(driverAndroid);

	}

	public ExplicitWaits(WebDriver driverWeb) {
		super(driverWeb);

	}

	public void explicitWaitForElement(String locatorType, String locator, int wait) {
		/*
		 * (new WebDriverWait(driverWeb, 30)).until(ExpectedConditions
		 * .presenceOfElementLocated(By.xpath(locator)));
		 */
		int second;
		for (second = 0;; second++) {
			if (second >= wait) {
				break;
			}
			if (isElementPresentCheck(locatorType, locator)) {
				break;
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		}
	}
	
	public void explicitWaitForElement(String locator, int wait) {
		
		 /*(new WebDriverWait(driverWeb, 30)).until(ExpectedConditions
		  .presenceOfElementLocated(By.xpath(locator)));*/
	
		 
		
	}

	public void waitforElementTextChange(String locator) {

		String retrieved_text = getElement("xpath", locator).getText();
		int second;
		for (second = 0;; second++) {
			if (second >= 25) {
				break;
			}
			if (!getElement("xpath", locator).getText().equals(retrieved_text)) {
				break;
			}
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		}
	}

}
