package com.mtv.tests;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;



public class Flash2 {


	 
	 @Test
	public void test() throws InterruptedException {
		//WebDriver driver = new FirefoxDriver();
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.permadi.com/tutorial/flashjscommand/");
		driver.manage().window().maximize();
		Thread.sleep(10000);
		Flash1 flashApp = new Flash1(driver, "myFlashMovie");
		Thread.sleep(10000);
	flashApp.callFlashObject("Play"); // first number
	Thread.sleep(3000L);
	flashApp.callFlashObject("StopPlay"); // operation

	Thread.sleep(3000L);
	flashApp.callFlashObject("Rewind");  
	System.out.println(flashApp.callFlashObject("GetVariable","/:message"));
	flashApp.callFlashObject("SetVariable","/:message","Learn Flash testing with Webdriver");
	System.out.println(flashApp.callFlashObject("GetVariable","/:message"));
	driver.quit();	 
	}
	
	
		

}